const {
  SITE_EMAIL_LOGO,
  emails_pass,
  emails_user,
  SITE_NAME,
  ROOT,
} = require("./settings.js");
const nodemailer = require("nodemailer");
const { OrderCompleted } = require("./emails-tempates/order-completed.js");
const { OrderCanceled } = require("./emails-tempates/canceled-order.js");
const { ContactReply } = require("./emails-tempates/contact-reply.js");
const { SuccessPay } = require("./emails-tempates/SuccessPay.js");
const { CancelPay } = require("./emails-tempates/CancelPay.js");

exports.SendEmail = (email_data) => {
  console.log("sending Email....");
  if (email_data.type === "payment-canceled") {
    var message = {
      from: SITE_NAME,
      to: email_data.email,
      subject: "Your Payment Request is Canceled!",
      text: `${email_data.message}`,
      html: CancelPay({ ...email_data, SITE_NAME, ROOT, SITE_EMAIL_LOGO }),
    };
  }
  if (email_data.type === "payment-success") {
    var message = {
      from: SITE_NAME,
      to: email_data.email,
      subject: "Payment successfully Recharged!",
      text: `${email_data.message}`,
      html: SuccessPay({ ...email_data, SITE_NAME, ROOT, SITE_EMAIL_LOGO }),
    };
  }
  if (email_data.type === "contact-reply") {
    var message = {
      from: SITE_NAME,
      to: email_data.email,
      subject: SITE_NAME + " replied on your feedback.",
      text: `${email_data.message}`,
      html: ContactReply({ ...email_data, SITE_NAME, ROOT, SITE_EMAIL_LOGO }),
    };
  }
  if (email_data.type === "complete") {
    var message = {
      from: SITE_NAME,
      to: email_data.email,
      subject: "Congratulations Your Order Completed successfully!",
      text: `Your order successfully completed! Go to check your order status ${email_data.link}`,
      html: OrderCompleted({ ...email_data, SITE_NAME, ROOT, SITE_EMAIL_LOGO }),
    };
  }
  if (email_data.type === "canceled") {
    var message = {
      from: SITE_NAME,
      to: email_data.email,
      subject: "Your Order has been canceled further see the reasons!",
      text: `Your Order has been canceled further see the reasons or contact to the website admins. your order ${email_data.link}`,
      html: OrderCanceled({ ...email_data, SITE_NAME, ROOT, SITE_EMAIL_LOGO }),
    };
  }

  let mailTransporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: emails_user,
      pass: emails_pass,
    },
  });
  return mailTransporter.sendMail(message, function (err, data) {
    if (err) {
      console.log("Error Occurs", err);
      return err;
    } else {
      console.log("Email sent successfully");
      return "email send";
    }
  });
};
