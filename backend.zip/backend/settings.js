exports.DATABASE_HOST = "localhost";
exports.DATABASE_USER = "root";
exports.DATABASE_PASS = "";
exports.DATABASE_NAME = "FAST_u";
exports.DEFAULT_CATEGORY_KEY = "KEKYIqj3dfhkF75GOfQC";
exports.emails_user = "zohaibjozvi@gmail.com";
exports.emails_pass = "csbihwfucstimmmr";
exports.SITE_NAME = "FS UNLOCKER";
exports.ROOT = "http://localhost:3000";
exports.SITE_EMAIL_LOGO =
  "https://firmwaresupport.com/media/site/1-01630924369.png";
