const mysql = require("mysql");
const DATABASE_HOST="127.0.0.1";
 const DATABASE_USER="gdriyeft_fast_user";
 const DATABASE_PASS="Dk!4wcj90[pf";
 const DATABASE_NAME="gdriyeft_fast";
const db = mysql.createConnection({
  host: DATABASE_HOST,
  user: DATABASE_USER,
  password: DATABASE_PASS,
  database: DATABASE_NAME,
});
db.connect((err) => {
  if (err) throw err;
});
module.exports = db;
