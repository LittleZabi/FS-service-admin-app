// // Objec relational mapping
// import { randoms } from "./functions.js";
// import db from "./database.js";
// export const orm = {
//   add_new_cat: function (value, FallJunk) {
//     const slug = randoms(20);
//     let existance = 0;
//     const sql = "SELECT category FROM services_category WHERE category = ?";
//     db.query(sql, [value["catname"]], (err, success) => {
//       if (err) FallJunk(null, err);
//       else if (success.length > 0) {
//         FallJunk({ condition: "exist" }, null);
//       } else {
//         const sql =
//           "INSERT INTO `services_category` (`category`, `slug`) VALUES(?,?)";
//         db.query(sql, [catname, slug], (err, success) => {
//           if (err) FallJunk(null, err);
//           FallJunk({ condition: "success" }, null);
//         });
//       }
//     });
//   },
// };
