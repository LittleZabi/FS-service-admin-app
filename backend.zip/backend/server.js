const express = require("express");
const db = require("./database.js");
const { pass_to_hash, randoms } = require("./functions.js");
const server = express();
const bodyParser = require("body-parser");
const { DEFAULT_CATEGORY_KEY, ROOT, SITE_NAME } = require("./settings.js");
const { SendEmail } = require("./emails.js");
server.use(bodyParser.urlencoded({ extended: false }));
server.use(bodyParser.json());

// server.get('/admin/api/test', (req, res)=>{res.send('okkey admin is working.....')})

server.get("/admin/api/md5/:text", (req, res) => {
  const text = req.params.text;
  const md5 = pass_to_hash(text);
  res.send(md5);
});

server.get("/admin/api/get-dashboard/:table", (req, res) => {
  let table = req.params.table;
  let sql = "";
  if (table === "orders" || table === "payments")
    sql = `SELECT status FROM ${table}`;
  if (table === "services_list") sql = `SELECT active FROM ${table}`;
  if (table === "services_category") sql = `SELECT active FROM ${table}`;
  if (table === "Users") {
    table = "users";
    sql = `SELECT activated FROM ${table}`;
  }
  if (table === "contact") sql = `SELECT replied FROM ${table}`;
  db.query(sql, (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});
server.post("/admin/api/cancel-payment", (req, res) => {
  const { email, reqSlug, user, ReqAmount, currency, username } = req.body;
  const sql =
    "UPDATE payments SET status = 'canceled' WHERE slug = ? AND user = ?";
  db.query(sql, [reqSlug, user], (err, suc) => {
    if (err) throw err;
    const contact_data = {
      type: "payment-canceled",
      message: `
        Your request of ${ReqAmount}${currency} is canceled from the customer support of ${SITE_NAME}.
        please check your account to find the reason of cancellation OR contact with our agent now!
      `,
      email,
      name: username,
    };
    SendEmail(contact_data);
    res.send({ condition: "success" });
  });
});
server.get("/admin/api/currencyExchangeApiKey/:convert", (req, res) => {
  const convert = req.params.convert;
  const url = `https://free.currconv.com/api/v7/convert?q=${convert}&compact=ultra&apiKey=374417fa4a6c071cb89e`;
  res.send(url);
});

server.post("/admin/api/set-payment", (req, res) => {
  const { email, reqSlug, user, ReqAmount, currency, username, RechAmount } =
    req.body;
  const sql = "UPDATE users SET crnt_balance = crnt_balance + ? WHERE slug = ?";
  db.query(sql, [RechAmount, user], (err, succ) => {
    if (err) throw err;
    const sql =
      "UPDATE payments SET status = 'complete' WHERE slug = ? AND user = ?";
    db.query(sql, [reqSlug, user], (err, suc) => {
      if (err) throw err;
      const contact_data = {
        type: "payment-success",
        message: `
          Your request of ${ReqAmount}${currency} and total ${RechAmount}${currency} added on your account.
          please check your account ${ROOT}+/client. on any problim please contact with our agent now!
        `,
        email,
        name: username,
      };
      SendEmail(contact_data);
      res.send({ condition: "success" });
    });
    // res.send(succ);
  });
});
server.get("/admin/api/payment-req-view/:slug", (req, res) => {
  const slug = req.params.slug;
  const sql =
    "SELECT payments.*,users.firstname,users.lastname,users.crnt_balance FROM payments,users WHERE payments.user = users.slug AND payments.slug = ? ORDER BY payments.id DESC";
  db.query(sql, [slug], (err, suc) => {
    if (err) throw err;
    res.send({ payment_details: suc, condition: "success" });
  });
});
server.get("/admin/api/payment-request-list/", (req, res) => {
  const sql =
    "SELECT payments.*,users.firstname,users.lastname,users.crnt_balance FROM payments,users WHERE payments.user = users.slug ORDER BY payments.id DESC";
  db.query(sql, (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});

server.post("/admin/api/contact-repy", (req, res) => {
  const { msg, username, email, slug } = req.body;
  const sql = "UPDATE contact SET replied = 1 WHERE slug = ?";
  db.query(sql, [slug], (err, suc) => {
    if (err) throw err;
    const contact_data = {
      type: "contact-reply",
      message: msg,
      email,
      name: username,
    };
    SendEmail(contact_data);
    res.send({ condition: "success" });
  });
});

server.get("/admin/api/feedbacks", (req, res) => {
  const sql = "SELECT * FROM contact ORDER BY contact.id DESC LIMIT 25";
  db.query(sql, (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});

server.get("/admin/api/search/:select/:query", (req, res) => {
  const { select, query } = req.params;
  let sql = "";
  if (select === "service")
    sql = `SELECT service,srvc_slug,  id FROM services_list WHERE service LIKE '%${query}%' OR srvc_slug LIKE '%${query}%' OR id LIKE '%${query}%'  ORDER BY services_list.id DESC LIMIT 6`;
  if (select === "orders")
    sql = `SELECT orders.slug, orders.id,services_list.service, users.firstname,users.lastname FROM services_list, orders, users WHERE orders.slug LIKE '%${query}%' OR orders.id LIKE '%${query}%' AND orders.user = users.slug AND orders.service = services_list.srvc_slug ORDER BY orders.id DESC LIMIT 6`;

  if (select === "categories")
    sql = `SELECT category, id, service_type, slug FROM services_category WHERE slug LIKE '%${query}%' OR id LIKE '%${query}%' OR category LIKE '%${query}%' ORDER BY id DESC  LIMIT 6`;
  if (select === "users")
    sql = `SELECT firstname, email, lastname, id, slug FROM users WHERE slug LIKE '%${query}%' OR id LIKE '%${query}%' OR firstname LIKE '%${query}%' OR lastname LIKE '%${query}%' ORDER BY id DESC LIMIT 6`;
  db.query(sql, (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});

server.get("/admin/api/user-action/:action/:slug", (req, res) => {
  const { action, slug } = req.params;
  let sql = "";
  let para = [];
  if (action === "delete") {
    sql = "DELETE FROM users WHERE slug =  ?";
  }
  if (action === "disable") {
    sql = "UPDATE users SET activated = 0 WHERE slug = ?";
  }
  if (action === "enable") {
    sql = "UPDATE users SET activated = 1 WHERE slug = ?";
  }
  db.query(sql, [slug], (err, suc) => {
    if (err) throw err;
    res.send({ condition: "success" });
  });
});
server.post("/admin/api/new-user/", (req, res) => {
  const {
    firstname,
    lastname,
    password,
    phone,
    address1,
    address2,
    country,
    state,
    city,
    postal,
    currency,
    email,
  } = req.body.formData;
  if (
    email === "" ||
    password === "" ||
    firstname === "" ||
    lastname === "" ||
    address1 === "" ||
    phone === "" ||
    currency === ""
  ) {
    res.send({ condition: "InputNotFilled" });
    return 0;
  } else {
    const slug = randoms(60);
    const activation_token = randoms(19);
    const password_hash = pass_to_hash(password);
    db.query(
      "SELECT `email` FROM `users` WHERE `email` = ?",
      [email],
      (err, succ) => {
        if (err) throw err;
        if (succ.length > 0) {
          res.send({ condition: "emailExist" });
          return 0;
        } else {
          const sql =
            "INSERT INTO `users` (`email`, `password`, `firstname`, `lastname`, `address1`, `address2`, `country`, `state`, `city`, `postal`, `phone`,  `slug`, `activation_token`, `currency`, `activated`) VALUES (?, ?, ?,  ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?, 1)";
          db.query(
            sql,
            [
              email,
              password_hash,
              firstname,
              lastname,
              address1,
              address2,
              country,
              state,
              city,
              postal,
              phone,
              slug,
              activation_token,
              currency,
            ],
            (err, suc) => {
              if (err) throw err;
              res.send({ condition: "success" });
            }
          );
        }
      }
    );
  }
});
server.post("/admin/api/update-user/", (req, res) => {
  const {
    firstname,
    lastname,
    address1,
    phone,
    address2,
    country,
    state,
    city,
    postal,
    slug,
    currency,
    password,
    email,
  } = req.body.formData;
  if (
    slug === "" ||
    firstname === "" ||
    lastname === "" ||
    address1 === "" ||
    currency === "" ||
    email === ""
  ) {
    res.send({ condition: "dataIsNotEnough" });
  } else {
    let data = [];
    let sql = [];
    if (password === "") {
      let sql =
        "UPDATE `users` SET phone = ?, `firstname` = ?, `email` = ?, `lastname` = ?, `address1` = ?, `address2` = ?, `country` = ?, `state` = ?, `city` = ?,`currency`= ?, `postal` = ? WHERE `slug` = ?";
      data = [
        phone,
        firstname,
        email,
        lastname,
        address1,
        address2,
        country,
        state,
        city,
        currency,
        postal,
        slug,
      ];
      db.query(sql, data, (err, suc) => {
        if (err) throw err;
        res.send({ condition: "updated" });
      });
    } else {
      let password_ = pass_to_hash(password);
      let sql =
        "UPDATE `users` SET phone = ?, `firstname` = ?,email = ?, password = ?, `lastname` = ?, `address1` = ?, `address2` = ?, `country` = ?, `state` = ?, `city` = ?,`currency`= ?, `postal` = ? WHERE `slug` = ?";
      data = [
        phone,
        firstname,
        email,
        password_,
        lastname,
        address1,
        address2,
        country,
        state,
        city,
        currency,
        postal,
        slug,
      ];
      db.query(sql, data, (err, suc) => {
        if (err) throw err;
        res.send({ condition: "updated" });
      });
    }
  }
});

server.get("/admin/api/users", (req, res) => {
  const sql = "SELECT * FROM users WHERE 1 ORDER BY users.id DESC";
  db.query(sql, (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});

server.post("/admin/api/update-DefLabels/", (req, res) => {
  const { DefValue, id } = req.body.cat_data;
  console.log(DefValue, id);
  const sql = "UPDATE `srvcdefaults` SET `value` = ? WHERE `id` = ?";
  db.query(sql, [DefValue, id], (err, suc) => {
    if (err) throw err;
    res.send({ condition: "success" });
  });
});

// server.get("/admin/api/delete-def-label/slug", (req, res) => {
//   const sql = "DELETE FROM `srvcdefaults` WHERE id = ?";
//   db.query(sql, [req.params.slug], (err, suc) => {
//     if (err) throw err;
//     res.send({ condition: "success" });
//   });
// });
server.get("/admin/api/get-def-label/:slug", (req, res) => {
  const sql = "SELECT * FROM srvcdefaults WHERE id = ?";
  db.query(sql, [req.params.slug], (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});
server.get("/admin/api/getDefaults/", (req, res) => {
  const sql =
    "SELECT `value`,`label`,`id`,active FROM `srvcdefaults` WHERE `active` = 1";
  db.query(sql, (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});
server.get("/admin/api/user-view/:slug", (req, res) => {
  const slug = req.params.slug;
  const sql =
    "SELECT `id`,`activated`, `email`, `currency`, `crnt_balance`, `total_spent`, `firstname`, `lastname`, `avatar`, `rating`, `address1`, `address2`, `country`, `state`, `city`, `postal`, `phone`, `datetime`, `slug` FROM `users` WHERE slug = ?";
  db.query(sql, [slug], (err, succ) => {
    if (err) throw err;
    res.send(succ);
  });
});
server.post("/admin/api/order-action/", (req, res) => {
  const {
    action,
    slug,
    clientMsg,
    email,
    name,
    order_id,
    src_name,
    src_paid_price,
    src_user,
    src_order_status,
  } = req.body;
  const sql = "UPDATE orders SET status = ? WHERE slug = ?";
  db.query(sql, [action, slug], (err, suc) => {
    if (err) throw err;
    if (action === "complete" && src_order_status === "canceled") {
      const sql =
        "UPDATE users SET crnt_balance = crnt_balance - ? WHERE slug = ?";
      db.query(sql, [src_paid_price, src_user], (err, update_succ) => {
        if (err) throw err;
      });
    }
    if (action === "canceled") {
      const sql =
        "UPDATE users SET crnt_balance = crnt_balance + ?, total_spent = total_spent - ? WHERE slug = ?";
      db.query(
        sql,
        [src_paid_price, src_paid_price, src_user],
        (err, update_succ) => {
          if (err) throw err;
        }
      );
    }
    if (action === "complete" || action === "canceled") {
      const link = ROOT + "/my-order/" + order_id;
      const email_data = {
        type: action === "complete" ? "complete" : "canceled",
        message: clientMsg,
        name,
        link,
        email,
        order_name: src_name,
      };
      SendEmail(email_data);
    }
    res.send({ condition: "success" });
  });
});

server.get("/admin/api/order-view/:slug", (req, res) => {
  const slug = req.params.slug;

  // const sql =
  //   "SELECT `orders`.*, services_list.* AS service_detail, users.* as user_detail FROM orders, users, services_list WHERE orders.user = users.slug and orders.service = services_list.srvc_slug AND `orders`.`slug` = ?";
  const sql = "SELECT * FROM orders WHERE slug = ?";
  db.query(sql, [slug], (err, order_details) => {
    if (err) throw err;
    if (order_details.length > 0) {
      const service_slug = order_details[0].service;
      const sql =
        "SELECT `id`, `service`,`deli_time`, `price`, `srvc_slug`, `on_created`, `input1`, `input2`, `input3`, `input4` FROM services_list WHERE srvc_slug = ?";
      db.query(sql, [service_slug], (err, service_details) => {
        if (err) throw err;
        if (service_details.length > 0) {
          const user_slug = order_details[0].user;
          const sql =
            "SELECT `id`, `email`, `currency`, `crnt_balance`, `firstname`, `lastname`, `rating`, `address1`, `address2`, `country`, `state`, `city`, `postal`, `phone`, `slug` FROM users WHERE slug = ?";
          db.query(sql, [user_slug], (err, user_details) => {
            if (err) throw err;
            if (user_details.length > 0) {
              const rating_slug = user_details[0].rating;
              const sql =
                "SELECT `category`, `discount`,`stars`, `slug` FROM `user_rating` WHERE slug = ?";
              let discount_details = [
                {
                  id: 1,
                  category: "Bronze",
                  discount: 0,
                  slug: "ZPBMYgGHzKxdzRtszTMuRWzQwXNcQXFdzBwTfTRseCFuCVOgDMwtyAxzTUMM",
                },
              ];
              db.query(sql, [rating_slug], (err, discDetails) => {
                if (err) throw err;
                if (discDetails.length > 0) {
                  discount_details = discDetails;
                }
                res.send({
                  condition: "success",
                  order_details,
                  service_details,
                  user_details,
                  discount_details,
                });
              });
            } else {
              res.send({ condition: "UserNotExist" });
            }
          });
        } else {
          res.send({ condition: "SrvcNotExist" });
        }
      });
      // res.send({ condition: "success", order_details: succ });

      // const val = succ[0].service_type;
      // const cat = succ[0].category;
      // const sql =
      //   "SELECT form_details.input1, form_details.input2, form_details.input3, `services_category`.`category` as cat_name FROM `form_details`, `services_category` WHERE `form_details`.`service_type` = ? AND services_category.slug = ?";
      // db.query(sql, [val, cat], (err, suc) => {
      //   if (err) throw err;

      //   res.send({ condition: "success", order_details: succ, field: suc });
      // });
    } else {
      res.send({ condition: "notExist" });
    }
  });
});

server.get("/admin/api/getOrdersList/:filter", (req, res) => {
  const filter = req.params.filter;
  let sql = "";
  let values = [];
  if (filter !== "all") {
    sql =
      "SELECT `orders`.`datetime`,`orders`.`paid`, orders.id, orders.status, services_list.service, orders.slug, users.firstname FROM orders, users, services_list WHERE orders.user = users.slug and orders.service = services_list.srvc_slug AND orders.status = ? ORDER BY orders.id DESC";
    values.unshift(filter);
  } else
    sql =
      "SELECT `orders`.`datetime`,`orders`.`paid`, orders.id, orders.status, services_list.service, orders.slug, users.firstname FROM orders, users, services_list WHERE orders.user = users.slug and orders.service = services_list.srvc_slug ORDER BY orders.id DESC";
  db.query(sql, values, (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});

server.post("/admin/api/update-inputs", (req, res) => {
  const data = req.body.data;
  const sql =
    "UPDATE `form_details` SET `input1` = ?, `input2` = ?, `input3`=? WHERE `id` = ?";
  db.query(sql, [data.inp1, data.inp2, data.inp3, data.id], (err, suc) => {
    if (err) throw err;
    res.send("success");
  });
});
// adding new service

server.get("/admin/api/getInputs", (req, res) => {
  const sql = "SELECT * FROM form_details";
  db.query(sql, (err, suc) => {
    if (err) throw err;
    res.send(suc);
  });
});
server.post("/admin/api/admin-login", (req, res) => {
  const { username, password } = req.body.user;
  if (username.length > 0) {
    if (password.length > 0) {
      const pass_hash = pass_to_hash(password);
      let sql = "SELECT * FROM `admins` WHERE `username` = ?";
      db.query(sql, [username], (err, succ) => {
        if (err) throw err;
        if (succ.length > 0) {
          if (succ[0].active === 1) {
            sql =
              "SELECT `username`, `slug` FROM `admins` WHERE `username` = ? AND `password` = ? AND `active` = 1";
            db.query(sql, [username, pass_hash], (err, suc) => {
              if (err) throw err;
              if (suc.length > 0) {
                res.send({
                  ...suc,
                  condition: "success",
                });
              } else res.send({ condition: "user-invalid-pass" });
            });
          } else res.send({ condition: "user-not-active" });
        } else res.send({ condition: "user-not-exist" });
      });
    } else res.send({ condition: "empty-pass" });
  } else res.send({ condition: "empty-user" });
});
server.post("/admin/api/update-service/", (req, res) => {
  const {
    service_name,
    category,
    deliver,
    price,
    description,
    src_slug,
    status,
    srvc_input1,
    srvc_input2,
    srvc_input3,
    srvc_input4,
  } = req.body.service_data;
  // const active_state = status === "on" ? 1 : 0;
  const sql =
    "UPDATE `services_list` SET service = ?, category = ?, deli_time = ?, price = ?, description = ?, active = ?, input1 = ?, input2 = ?, input3 = ?, input4 = ? WHERE srvc_slug = ?";
  db.query(
    sql,
    [
      service_name,
      category,
      deliver,
      price,
      description,
      status,
      srvc_input1,
      srvc_input2,
      srvc_input3,
      srvc_input4,
      src_slug,
    ],
    (err, suc) => {
      if (err) throw err;
      res.send("success");
    }
  );
});
server.post("/admin/api/new-service/", (req, res) => {
  const {
    service_name,
    category,
    deliver,
    price,
    description,
    srvc_input1,
    srvc_input2,
    srvc_input3,
    srvc_input4,
  } = req.body.service_data;
  const slug = randoms(20);
  const sql = "SELECT `service` FROM `services_list` WHERE `service` = ?";
  db.query(sql, [service_name], (err, suc) => {
    if (err) throw err;
    else if (suc.length > 0) {
      res.send("exist");
      return 0;
    } else {
      const sql =
        "INSERT INTO `services_list` (`service`, `category`, `description`, `deli_time`, `price`, `input1`, `input2`, `input3`, `input4`, `srvc_slug`) VALUES (?,?,?,?,?,?,?,?,?,?)";
      db.query(
        sql,
        [
          service_name,
          category,
          description,
          deliver,
          price,
          srvc_input1,
          srvc_input2,
          srvc_input3,
          srvc_input4,
          slug,
        ],
        (err, suc) => {
          if (err) throw err;
          res.send("success");
        }
      );
    }
  });
});
// service list modal view
server.get("/admin/api/srvc-list-view/:slug", (req, res) => {
  const sql =
    "SELECT services_list.*, services_category.category, services_category.slug from services_list, services_category WHERE services_list.srvc_slug = ? and services_list.category = services_category.slug";
  const slug = req.params.slug;
  db.query(sql, [slug], (error, result) => {
    if (error) {
      res.send({ sql_error: error.errno });
      throw error;
    }
    res.send(result);
  });
});
// service list
server.get("/admin/api/services-list", (req, res) => {
  const sql =
    "SELECT services_list.*, services_category.category,services_category.service_type from services_list, services_category WHERE  services_list.category = services_category.slug  ORDER BY id DESC";
  db.query(sql, (error, result) => {
    if (error) {
      res.send({ sql_error: error.errno });
      throw error;
    }
    res.send(result);
  });
});
// delete category
server.get("/admin/api/delete-cat/:slug", (req, res) => {
  const slug = req.params.slug;
  if (slug === DEFAULT_CATEGORY_KEY) {
    res.send("DefCatNotDel");
    return;
  }
  const sql = "UPDATE services_list SET category = ? WHERE category = ?";
  db.query(sql, [DEFAULT_CATEGORY_KEY, slug], (err, suc) => {
    const sql = "DELETE FROM `services_category` WHERE slug = ?";
    db.query(sql, [slug], (err, success) => {
      if (err) throw err;
      res.send("success");
    });
  });
});
// delete service
server.get("/admin/api/delete-srvc/:slug", (req, res) => {
  const slug = req.params.slug;
  const sql = "DELETE FROM services_list WHERE srvc_slug = ?";
  db.query(sql, [slug], (err, success) => {
    if (err) throw err;
    res.send("success");
  });
});

// update category
server.post("/admin/api/update-category/", (req, res) => {
  const { cat_slug, cate_name, cat_status, cat_oldname, cat_service_type } =
    req.body.cat_data;
  if (cat_oldname === cate_name) {
    const sql =
      "UPDATE `services_category` SET `service_type` = ?, active = ? WHERE slug = ?";
    db.query(sql, [cat_service_type, cat_status, cat_slug], (err, success) => {
      res.send({
        condition: "success",
      });
    });
  } else {
    const sql = "SELECT category FROM services_category WHERE category = ?";
    db.query(sql, [cate_name], (err, success) => {
      if (err) {
        throw err;
      } else if (success.length > 0) {
        res.send({ condition: "exist" });
        return 0;
      } else {
        const sql =
          "UPDATE `services_category` SET `category` = ?, service_type = ? ,  active = ? WHERE slug = ?";
        db.query(
          sql,
          [cate_name, cat_service_type, cat_status, cat_slug],
          (err, success) => {
            res.send({
              condition: "success",
            });
          }
        );
      }
    });
  }
});

// adding new category
server.post("/admin/api/new-category/", (req, res) => {
  const { cate_name, cate_type } = req.body;
  const slug = randoms(20);
  const sql = "SELECT category FROM services_category WHERE category = ?";
  db.query(sql, [cate_name], (err, success) => {
    if (err) {
      throw err;
    } else if (success.length > 0) {
      res.send({ condition: "exist" });
      return 0;
    } else {
      const sql =
        "INSERT INTO `services_category` (`category`,`service_type`, `slug`) VALUES(?,?,?)";
      db.query(sql, [cate_name, cate_type, slug], (err, success) => {
        res.send({
          condition: "success",
        });
      });
    }
  });
});
server.get("/admin/api/get-cat/:slug", (req, res) => {
  const sql =
    "SELECT category, service_type, slug, active FROM services_category WHERE slug = ?";
  db.query(sql, [req.params.slug], (err, result) => {
    if (err) throw err;
    res.send(result);
  });
});
server.get("/admin/api/cat-list-details", (req, res) => {
  const sql =
    "SELECT id, category,service_type, slug, active, date FROM services_category ORDER BY id DESC";
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.send(result);
  });
});
server.get("/admin/api/cat-list", (req, res) => {
  const sql =
    "SELECT id, category, slug, active, date FROM services_category WHERE active=1 ORDER BY id DESC";
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.send(result);
  });
});

server.listen(5000, () => {
  console.log("running....");
});
