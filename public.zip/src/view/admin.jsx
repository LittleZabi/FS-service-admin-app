import Dashboard from "../components/dashboard";
import Edit from "../components/edit-src";
import NewPost from "../components/new";
import List from "../components/src-list";
import CatList from "../components/category-list";
import SrvcInputs from "../components/srvc-inputs";
import Orders from "../components/orders";
import UsersList from "../components/users";
import Feedbacks from "../components/feedbacks";
import Payments from "../components/payments";
import DefLabels from "../components/def-labels";
import AddUser from "../components/modal.components/add-new-user";
const Admin = ({ view }) => {
  return (
    <div className="admin-main">
      {view === "new" ? (
        <NewPost />
      ) : view === "edit" ? (
        <Edit />
      ) : view === "list" ? (
        <List />
      ) : view === "cat-list" ? (
        <CatList />
      ) : view === "srvc-inputs" ? (
        <SrvcInputs />
      ) : view === "payments" ? (
        <Payments />
      ) : view === "orders" ? (
        <Orders />
      ) : view === "def-labels" ? (
        <DefLabels />
      ) : view === "new-user" ? (
        <AddUser />
      ) : view === "users-list" ? (
        <UsersList />
      ) : view === "feebacks" ? (
        <Feedbacks />
      ) : (
        <Dashboard />
      )}
    </div>
  );
};
export default Admin;
