const NotFound = () => {
  return <div className="page-view layout">Not Found 404</div>;
};
export default NotFound;
