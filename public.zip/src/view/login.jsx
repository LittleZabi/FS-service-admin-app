import { useState } from "react";
import axios from "axios";
import "../styles/login.scss";
import Loading from "../components/loading";
import InlineMessage from "../components/inilne-message";
const Login = () => {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(false);
  const GetLogin = async (user) => {
    setLoading(true);
    await axios.post("/admin/api/admin-login", { user }).then((res) => {
      const condition = res.data.condition;
      if (condition === "success") {
        let user = res.data[0];
        user = JSON.stringify(user);
        localStorage.setItem("admin-user", user);
        setTimeout(() => {
          window.location.href = "/admin/";
        }, 500);
        setMessage({
          type: "success",
          message: "successfully logged! Redirecting...",
        });
      } else if (condition === "user-not-exist")
        setMessage({
          type: "alert",
          message: "user not exist please check your username.",
        });
      else if (condition === "user-not-active")
        setMessage({
          type: "alert",
          message: "user exist but not active please contact with super admin!",
        });
      else if (condition === "user-invalid-pass")
        setMessage({
          type: "alert",
          message:
            "incorrect password please check your password and try again!",
        });
      else if (condition === "empty-pass")
        setMessage({ type: "alert", message: "Enter your username...." });
      else if (condition === "empty-user")
        setMessage({ type: "alert", message: "Enter your password...." });

      setLoading(false);
    });
  };
  const handleForm = (e) => {
    e.preventDefault();
    const username = e.target["user-box"].value;
    const password = e.target["pass-box"].value;
    if (username.length > 4) {
      if (password.length > 4) {
        GetLogin({ username, password });
      } else setMessage({ type: "alert", message: "Enter your password...." });
    } else {
      setMessage({ type: "alert", message: "Enter your username...." });
    }
  };
  return (
    <div className="admin-bg admin-login">
      <div className="layout">
        <form onSubmit={handleForm}>
          <h3>Admin Login</h3>
          <br />
          <label htmlFor="user-box">Enter username</label>
          <input
            type="text"
            placeholder="enter your username..."
            id="user-box"
          />
          <label htmlFor="pass-box">Enter password</label>
          <input
            type="password"
            placeholder="enter your password..."
            id="pass-box"
          />
          <br />
          <br />

          <div style={{ textAlign: "center" }}>
            {message && (
              <InlineMessage type={message.type} message={message.message} />
            )}
            {loading && <Loading />}
          </div>

          {!loading && <input type="submit" value="submit" />}
        </form>
      </div>
    </div>
  );
};
export default Login;
