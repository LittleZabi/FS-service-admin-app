import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import Admin from "./view/admin";
import Header from "./components/header";
import SideBar from "./components/sidebar";
import Messages from "./components/messages";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SHOW_MESSAGE, SHOW_MODAL } from "./store/constants";
import ModalView from "./components/modal";
import Login from "./view/login";
const App = () => {
  const modal = useSelector((state) => state.TopReducer);
  const [loginState, setLoginState] = useState(true);
  const admin = () => {
    let user = localStorage.getItem("admin-user");
    if (user) {
      user = JSON.parse(user);
      setLoginState(user);
    } else {
      setLoginState(false);
    }
  };
  useEffect(() => {
    admin();
    if (document.querySelector(".nav-menu-btn svg")) {
      const btn = document.querySelector(".nav-menu-btn svg");
      modal.status && modal.payload.ModalType === "NavBar"
        ? btn.classList.add("open")
        : btn.classList.remove("open");
    }
  }, [modal.status, modal.payload.ModalType]);

  return (
    <BrowserRouter>
      {!loginState && <Login />}
      {loginState && (
        <>
          <Header />
          <main className="page-view">
            {modal.status === SHOW_MODAL ? (
              <ModalView ModalPayload={modal} />
            ) : (
              ""
            )}
            {modal.status === SHOW_MESSAGE ? (
              <Messages payload={modal.payload} />
            ) : (
              ""
            )}
            <SideBar />
            <Routes>
              <Route path="/" element={<Admin view="" />} />
              <Route path="/admin/" element={<Admin view="" />} />
              <Route path="/admin/new" element={<Admin view="new" />} />
              <Route path="/admin/list/" element={<Admin view="list" />} />
              <Route
                path="/admin/feebacks"
                element={<Admin view="feebacks" />}
              />
              <Route
                path="/admin/srvc-inputs/"
                element={<Admin view="srvc-inputs" />}
              />
              <Route
                path="/admin/payments"
                element={<Admin view="payments" />}
              />
              <Route
                path="/admin/cat-list/"
                element={<Admin view="cat-list" />}
              />
              <Route path="/admin/orders/" element={<Admin view="orders" />} />
              <Route
                path="/admin/users-list/"
                element={<Admin view="users-list" />}
              />
              <Route
                path="/admin/def-labels/"
                element={<Admin view="def-labels" />}
              />
              <Route
                path="/admin/new-user/"
                element={<Admin view="new-user" />}
              />
              <Route path="*" element={<Admin view="" />} />
            </Routes>
          </main>
        </>
      )}
    </BrowserRouter>
  );
};
export default App;
