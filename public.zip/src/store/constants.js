export const SHOW_MESSAGE = "SHOW_MESSAGE";
export const HIDE_MESSAGE = "HIDE_MESSAGE";
// modal actions
export const SHOW_MODAL = "SHOW_MODAL";
export const HIDE_MODAL = "HIDE_MODAL";

export const SRVC_ERR = "SRVC_ERR";
export const SRVC_REQ = "SRVC_REQ";
export const SRVC_SUC = "SRVC_SUC";

export const GET_CAT = "GET_CAT";

export const NEW_CAT_SUC = "NEW_CAT_SUC";
export const NEW_CAT_REQ = "NEW_CAT_REQ";
// export const NEW_CAT_CHECK_REQ = "NEW_CAT_CHECK_REQ";
// export const NEW_CAT_CHECK_COM = "NEW_CAT_CHECK_COM";
