import * as _action_ from "./constants";

export const SrvcCatList = (state = {}, action) => {
  switch (action.type) {
    case _action_.GET_CAT:
      return {
        cat_list: action.payload,
      };

    default:
      return state;
  }
};

export const CrncyExchangeRed = (
  state = { action: "pkr_to", currency: ["PKR_PKR", 1] },
  action
) => {
  switch (action.type) {
    case "CURRENCY_REQ":
      return {
        payload: state,
      };
    case "CURRENCY_SUCC":
      return {
        payload: action.payload,
      };
    default:
      return state;
  }
};
export const SrvcRed = (state = {}, action) => {
  switch (action.type) {
    case _action_.SRVC_REQ:
      return {
        loading: true,
        ER_Raise: false,
      };
    case _action_.SRVC_ERR:
      return {
        ER_Raise: action.payload,
        loading: false,
      };
    case _action_.SRVC_SUC:
      return {
        loading: false,
        ER_Raise: false,
        srvc_data: action.payload,
      };

    default:
      return state;
  }
};

export const TopReducer = (state = { status: "", payload: {} }, action) => {
  switch (action.type) {
    case _action_.SHOW_MODAL:
      return {
        status: action.type,
        payload: action.payload,
      };
    case _action_.HIDE_MODAL:
      return {
        status: action.type,
        payload: { ModalType: "" },
      };
    case _action_.SHOW_MESSAGE:
      return {
        status: action.type,
        payload: action.payload,
      };
    case _action_.HIDE_MESSAGE:
      return {
        status: "",
        payload: {},
      };
    default:
      return state;
  }
};
