import * as _action_ from "./constants";
// import Axios from "axios";
import axios from "axios";
export const ShowModalAction = (ModalType, data) => {
  return { type: _action_.SHOW_MODAL, payload: { ModalType, data } };
};

export const currencyExchangeAction = (currency, action) => (dispatch) => {
  const convert = currency.replace(/\s/g, "");
  dispatch({
    type: "CURRENCY_REQ",
  });
  const getCrncRate = async (crnc) => {
    if (convert !== "PKR_PKR") {
      try {
        return await axios
          .get("/admin/api/currencyExchangeApiKey/" + convert)
          .then((res) => {
            return axios.get(res.data);
          });
      } catch (error) {
        console.warn("Currency can't converting due to: ", error.message);
        return ["PKR_PKR", 1];
      }
    } else {
      return ["PKR_PKR", 1];
    }
  };
  if (convert !== "PKR_PKR") {
    getCrncRate(currency).then((res) => {
      if (res.data) {
        if (res.data[convert]) {
          if (action === "pkr_to") {
            dispatch({
              type: "CURRENCY_SUCC",
              payload: { action, currency: [convert, res.data[convert]] },
            });
          } else {
            dispatch({
              type: "CURRENCY_SUCC",
              payload: { action, currency: [convert, res.data[convert]] },
            });
          }
        } else {
          dispatch({
            type: "CURRENCY_SUCC",
            payload: { action, currency: ["PKR_PKR", 1] },
          });
        }
      } else {
        dispatch({
          type: "CURRENCY_SUCC",
          payload: { action, currency: ["PKR_PKR", 1] },
        });
      }
    });
  } else {
    dispatch({
      type: "CURRENCY_SUCC",
      payload: { action, currency: ["PKR_PKR", 1] },
    });
  }
};

export const CatListViewAction = () => async (dispatch) => {
  dispatch({
    type: _action_.SRVC_REQ,
  });
  try {
    const { data } = await axios.get("/admin/api/cat-list-details");
    dispatch({
      type: _action_.SRVC_SUC,
      payload: data,
    });
  } catch (OnError) {
    dispatch({
      type: _action_.SRVC_ERR,
      payload: OnError.message,
    });
  }
};

export const SearchAction = (selection, query) => {
  return { selection, query };
};

export const MessageAction = (
  classes = "",
  message = "",
  status = _action_.SHOW_MESSAGE
) => {
  return {
    type: status,
    payload: {
      classes,
      message,
    },
  };
};

export const SrvclistAction = () => async (dispatch) => {
  dispatch({
    type: _action_.SRVC_REQ,
  });
  try {
    const { data } = await axios.get("/admin/api/services-list");
    dispatch({ type: _action_.SRVC_SUC, payload: data });
  } catch (OnError) {
    dispatch({ type: _action_.SRVC_ERR, payload: OnError.message });
  }
};
export const service_cat_list = () => async (dispatch) => {
  const { data } = await axios.get("/admin/api/cat-list");
  dispatch({ type: _action_.GET_CAT, payload: data });
};
