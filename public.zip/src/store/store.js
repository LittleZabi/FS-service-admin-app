// import { createStore, combineReducers } from "redux";
import { applyMiddleware, createStore, compose, combineReducers } from "redux";
import { TopReducer, SrvcRed, SrvcCatList, CrncyExchangeRed } from "./reducers";
import thunk from "redux-thunk";
const initalState = {};

const reducer = combineReducers({
  TopReducer,
  SrvcRed,
  SrvcCatList,
  CrncyExchangeRed,
});

const composeEnhancer = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const store = createStore(
  reducer,
  initalState,
  composeEnhancer(applyMiddleware(thunk))
);
export default store;

// const store = createStore(reducer, initalState);
// export default store;
