import { FaTimes } from "react-icons/fa";
import { useDispatch } from "react-redux";
import { HIDE_MODAL } from "../store/constants";
import EditCat from "./modal.components/editcat";
import SrvcListView from "./modal.components/srvc-list";
import AddNewCat from "./modal.components/new-cat";
import Logout from "./modal.components/logout";
import OrderView from "./modal.components/order-view";
import UserView from "./modal.components/user-view";
import UserFeedbacks from "./modal.components/user-feedbacks";
import PaymentReqView from "./modal.components/pay-req-view";
import DefLableEdit from "./modal.components/def-edit-modal";
import UserEdit from "./modal.components/user-edit";
function ModalView({ ModalPayload }) {
  const modal_type = ModalPayload.payload.ModalType;
  const dispatch = useDispatch();
  return (
    <div className="blue-modal fading">
      <div className="inner-modal">
        <div className="modal-title-bar">
          <span
            onClick={() => {
              let modal = document.querySelector(".blue-modal");
              modal.classList.add("modal-close");
              setTimeout(() => {
                dispatch({ type: HIDE_MODAL });
              }, 300);
            }}
            className="button"
          >
            <FaTimes />
          </span>
        </div>
        <div className="modal-content">
          {modal_type === "NewCatModel" ? (
            <AddNewCat />
          ) : modal_type === "SrvcListView" ? (
            <SrvcListView ModalPayload={ModalPayload} />
          ) : modal_type === "EditCat" ? (
            <EditCat ModalPayload={ModalPayload} />
          ) : modal_type === "NavBar" ? (
            <Logout />
          ) : modal_type === "OrderView" ? (
            <OrderView ModalPayload={ModalPayload} />
          ) : modal_type === "pay-req-view" ? (
            <PaymentReqView ModalPayload={ModalPayload} />
          ) : modal_type === "user-view" ? (
            <UserView ModalPayload={ModalPayload} />
          ) : modal_type === "def-edit" ? (
            <DefLableEdit ModalPayload={ModalPayload} />
          ) : modal_type === "user-edit" ? (
            <UserEdit ModalPayload={ModalPayload} />
          ) : modal_type === "contact-reply" ? (
            <UserFeedbacks ModalPayload={ModalPayload} />
          ) : (
            ""
          )}
        </div>
        <br />
        <button
          className="close-modal-button"
          onClick={() => {
            let modal = document.querySelector(".blue-modal");
            modal.classList.add("modal-close");
            setTimeout(() => {
              dispatch({ type: HIDE_MODAL });
            }, 300);
          }}
        >
          Close
        </button>
        <br />
      </div>
    </div>
  );
}

export default ModalView;
