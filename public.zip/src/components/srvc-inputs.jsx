import { useEffect, useState } from "react";
import axios from "axios";
import InlineMessage from "./inilne-message";
export default function SrvcInputs() {
  const [inputs, setInputs] = useState({
    imei: { id: "" },
    server: { id: "" },
    remote: { id: "" },
    other: { id: "" },
  });
  const [MessageImei, setMessageImei] = useState(false);
  const [MessageRem, setMessageRem] = useState(false);
  const [MessageSer, setMessageSer] = useState(false);
  const [MessageOth, setMessageOth] = useState(false);
  const getInputs = async () => {
    await axios.get("/admin/api/getInputs").then((res) => {
      const inptus_ = res.data;
      const imei = inptus_.filter((e) => {
        return e.service_type === "imei";
      });
      const server = inptus_.filter((e) => {
        return e.service_type === "server";
      });
      const remote = inptus_.filter((e) => {
        return e.service_type === "remote";
      });
      const other = inptus_.filter((e) => {
        return e.service_type === "other";
      });

      setInputs({
        other: other[0],
        remote: remote[0],
        server: server[0],
        imei: imei[0],
      });
    });
  };
  const clearStates = () => {
    setMessageImei(false);
    setMessageRem(false);
    setMessageSer(false);
    setMessageOth(false);
  };
  const updateInputs = async (data, type) => {
    clearStates();
    const type_msg = "alert";
    const message = "Saving...";
    if (type === "imei") setMessageImei({ type: type_msg, message });
    if (type === "remote") setMessageRem({ type: type_msg, message });
    if (type === "server") setMessageSer({ type: type_msg, message });
    if (type === "other") setMessageOth({ type: type_msg, message });
    await axios.post("/admin/api/update-inputs", { data }).then((res) => {
      if (res.data === "success") {
        const message = "saved successfully...";
        const type_msg = "success";
        if (type === "imei") setMessageImei({ type: type_msg, message });
        if (type === "remote") setMessageRem({ type: type_msg, message });
        if (type === "server") setMessageSer({ type: type_msg, message });
        if (type === "other") setMessageOth({ type: type_msg, message });
      } else {
        const type_msg = "error";
        const message = "Error occured during updating fields.";
        if (type === "imei") setMessageImei({ type: type_msg, message });
        if (type === "remote") setMessageRem({ type: type_msg, message });
        if (type === "server") setMessageSer({ type: type_msg, message });
        if (type === "other") setMessageOth({ type: type_msg, message });
      }
    });
  };
  const handleImei = (e) => {
    e.preventDefault();
    const inp1 = e.target["imei-input-1"].value;
    const inp2 = e.target["imei-input-2"].value;
    const inp3 = e.target["imei-input-3"].value;
    const id = e.target["imei-id"].value;
    updateInputs({ inp1, inp2, inp3, id }, "imei");
  };
  const handleServer = (e) => {
    e.preventDefault();
    const inp1 = e.target["server-input-1"].value;
    const inp2 = e.target["server-input-2"].value;
    const inp3 = e.target["server-input-3"].value;
    const id = e.target["server-id"].value;
    updateInputs({ inp1, inp2, inp3, id }, "server");
  };
  const handleRemote = (e) => {
    e.preventDefault();
    const inp1 = e.target["remote-input-1"].value;
    const inp2 = e.target["remote-input-2"].value;
    const inp3 = e.target["remote-input-3"].value;
    const id = e.target["remote-id"].value;
    updateInputs({ inp1, inp2, inp3, id }, "remote");
  };
  const handleOthers = (e) => {
    e.preventDefault();
    const inp1 = e.target["other-input-1"].value;
    const inp2 = e.target["other-input-2"].value;
    const inp3 = e.target["other-input-3"].value;
    const id = e.target["other-id"].value;
    updateInputs({ inp1, inp2, inp3, id }, "other");
  };
  useEffect(() => {
    getInputs();
  }, []);
  return (
    <div className="layout">
      <h3>Services inputs Settings</h3>
      <form onSubmit={handleImei}>
        <h4>IMEI Labels</h4>
        <input type="hidden" id="imei-id" defaultValue={inputs.imei.id} />
        <label htmlFor="imei-input-1">input 1</label>
        <input
          defaultValue={inputs.imei.input1}
          type="text"
          id="imei-input-1"
        />
        <label htmlFor="imei-input-2">input 2</label>
        <input
          defaultValue={inputs.imei.input2}
          type="text"
          id="imei-input-2"
        />
        <label htmlFor="imei-input-3">input 3</label>
        <input
          defaultValue={inputs.imei.input3}
          type="text"
          id="imei-input-3"
        />
        <br />
        <button type="submit">
          <i className="fa fa-save"></i> Save
        </button>
        {MessageImei && (
          <InlineMessage
            type={MessageImei.type}
            message={MessageImei.message}
          />
        )}
        <hr />
      </form>
      <form onSubmit={handleServer}>
        <h4>SERVER Labels</h4>
        <input type="hidden" id="server-id" value={inputs.server.id} />
        <label htmlFor="server-input-1">input 1</label>
        <input
          defaultValue={inputs.server.input1}
          type="text"
          id="server-input-1"
        />
        <label htmlFor="server-input-2">input 2</label>
        <input
          defaultValue={inputs.server.input2}
          type="text"
          id="server-input-2"
        />
        <label htmlFor="server-input-3">input 3</label>
        <input
          defaultValue={inputs.server.input3}
          type="text"
          id="server-input-3"
        />
        <br />
        <button type="submit">
          <i className="fa fa-save"></i> Save
        </button>
        {MessageSer && (
          <InlineMessage type={MessageSer.type} message={MessageSer.message} />
        )}
        <hr />
      </form>
      <form onSubmit={handleRemote}>
        <h4>REMOTE Labels</h4>
        <input type="hidden" id="remote-id" value={inputs.remote.id} />
        <label htmlFor="remote-input-1">input 1</label>
        <input
          defaultValue={inputs.remote.input1}
          type="text"
          id="remote-input-1"
        />
        <label htmlFor="remote-input-2">input 2</label>
        <input
          defaultValue={inputs.remote.input2}
          type="text"
          id="remote-input-2"
        />
        <label htmlFor="remote-input-3">input 3</label>
        <input
          defaultValue={inputs.remote.input3}
          type="text"
          id="remote-input-3"
        />
        <br />
        <button type="submit">
          <i className="fa fa-save"></i> Save
        </button>
        {MessageRem && (
          <InlineMessage type={MessageRem.type} message={MessageRem.message} />
        )}
        <hr />
      </form>
      <form onSubmit={handleOthers}>
        <h4>Others Labels</h4>
        <input type="hidden" id="other-id" value={inputs.other.id} />
        <label htmlFor="other-input-1">input 1</label>
        <input
          defaultValue={inputs.other.input1}
          type="text"
          id="other-input-1"
        />
        <label htmlFor="other-input-2">input 2</label>
        <input
          defaultValue={inputs.other.input2}
          type="text"
          id="other-input-2"
        />
        <label htmlFor="other-input-3">input 3</label>
        <input
          defaultValue={inputs.other.input3}
          type="text"
          id="other-input-3"
        />
        <br />
        <button type="submit">
          <i className="fa fa-save"></i> Save
        </button>
        {MessageOth && (
          <InlineMessage type={MessageOth.type} message={MessageOth.message} />
        )}
        <hr />
      </form>
    </div>
  );
}
