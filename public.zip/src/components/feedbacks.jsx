import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { ShowModalAction } from "../store/actions";
import Loading from "./loading";

function Feedbacks() {
  const dispatch = useDispatch();
  const [feedbacks, setFeedbacks] = useState([]);
  const [loading, setLoading] = useState(false);
  const getFeedbacks = async () => {
    setLoading(true);
    try {
      await axios.get("/admin/api/feedbacks").then((res) => {
        if (res.data.length > 0) {
          setLoading(false);
          setFeedbacks(res.data);
        }
      });
    } catch (err) {
      setLoading(false);
      alert(err.message);
    }
  };
  const CompRefresh = () => {
    getFeedbacks();
  };
  useEffect(() => {
    getFeedbacks();
  }, []);
  const DataTable = () => {
    return (
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>username</th>
            <th>email</th>
            <th>message</th>
            <th>Readed</th>
          </tr>
        </thead>
        <tbody>
          {feedbacks.map((user) => {
            return (
              <tr
                key={user.id}
                onClick={() => dispatch(ShowModalAction("contact-reply", user))}
              >
                <td>{user.id}</td>
                <td>
                  {user.username}
                  <span></span>{" "}
                </td>
                <td>{user.email}</td>
                <td>
                  {user.text.substring(0, 150)}
                  <small>
                    <strong>
                      {user.text.length > 150 ? "...Read More" : ""}
                    </strong>
                  </small>
                </td>
                <td
                  style={
                    user.replied === 1
                      ? { background: "#afdbff", textAlign: "center" }
                      : { background: "#f3b49d", textAlign: "center" }
                  }
                >
                  {" "}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    );
  };
  return (
    <div className="layout">
      <div className="cat-list flex-box">
        <h3>Users</h3>
        <p className="refresh-btn" onClick={CompRefresh}>
          <i className="fa fa-refresh"></i>
        </p>
      </div>
      <div className="list-view">
        {loading && <Loading />}
        {!loading && <DataTable />}
      </div>
    </div>
  );
}
export default Feedbacks;
