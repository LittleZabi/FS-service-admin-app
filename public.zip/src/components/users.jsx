import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { ShowModalAction } from "../store/actions";
import InlineMessage from "./inilne-message";
import Loading from "./loading";

function UsersList() {
  const dispatch = useDispatch();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState(false);
  const getUsers = async () => {
    setLoading(true);
    try {
      await axios.get("/admin/api/users").then((res) => {
        if (res.data.length > 0) {
          setLoading(false);
          setUsers(res.data);
        } else {
          setLoading(false);
          setAlert({ type: "alert", message: "No user found!" });
        }
      });
    } catch (err) {
      setAlert({ type: "alert", message: "Error: " + err.message });
      setLoading(false);
    }
  };
  const CompRefresh = () => {
    getUsers();
  };
  useEffect(() => {
    getUsers();
  }, []);
  const DataTable = () => {
    return (
      <>
        {alert && <InlineMessage type={alert.type} message={alert.message} />}
        {!alert && (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>username</th>
                <th>email</th>
                <th>Current Balance</th>
                <th>Total spent</th>
                <th>status</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => {
                return (
                  <tr
                    key={user.id}
                    onClick={() =>
                      dispatch(ShowModalAction("user-view", user.slug))
                    }
                  >
                    <td>{user.id}</td>
                    <td>{user.firstname + " " + user.lastname} </td>
                    <td>{user.email}</td>
                    <td>
                      {user.crnt_balance}
                      {user.currency}
                    </td>
                    <td>
                      {user.total_spent}
                      {" PKR"}
                    </td>
                    <td
                      style={
                        user.activated === 1
                          ? { background: "#afdbff", textAlign: "center" }
                          : { background: "#f3b49d", textAlign: "center" }
                      }
                    ></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </>
    );
  };
  return (
    <div className="layout">
      <div className="cat-list flex-box">
        <h3>Users</h3>
        <p className="refresh-btn" onClick={CompRefresh}>
          <i className="fa fa-refresh"></i>
        </p>
      </div>
      <div className="list-view">
        {loading && <Loading />}
        {!loading && <DataTable />}
      </div>
    </div>
  );
}
export default UsersList;
