import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { CatListViewAction, ShowModalAction } from "../store/actions";
import ErrorMessage from "./error-msg";
import Loading from "./loading";
import axios from "axios";
import InlineMessage from "./inilne-message";

function Orders() {
  const dispatch = useDispatch();
  const [OrderList, setOrderList] = useState([]);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(false);
  const [filter, setFilter] = useState("all");
  const getOrdersList = async (filter = "all") => {
    setMessage(false);
    setError(false);
    try {
      setLoading(true);
      await axios.get("/admin/api/getOrdersList/" + filter).then((res) => {
        if (res.data.length > 0) setOrderList(res.data);
        else {
          setOrderList([]);
          setMessage({
            type: "alert",
            message: "Empty " + filter + " Orders.",
          });
        }
        setLoading(false);
      });
    } catch (error) {
      setLoading(false);
      setError({ message: error.message });
    }
  };
  const CompRefresh = () => {
    getOrdersList(filter);
  };
  const handleFilter = (e) => {
    const filter_value = e.target.value;
    setFilter(filter_value);
    getOrdersList(filter_value);
  };
  useEffect(() => {
    getOrdersList();
    dispatch(CatListViewAction());
  }, [dispatch]);
  const DataTable = () => {
    return (
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>User</th>
            <th>Service</th>
            <th>Paid</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>

        <tbody>
          {OrderList.map((order) => {
            return (
              <tr
                key={order.id}
                onClick={() =>
                  dispatch(ShowModalAction("OrderView", order.slug))
                }
              >
                <td>{order.id}</td>
                <td>{order.firstname}</td>
                <td>{order.service}</td>
                <td style={{ fontWeight: "bold" }}>
                  {order.paid}
                  {" PKR"}
                </td>
                <td
                  className={
                    order.status === "complete"
                      ? "complete"
                      : order.status === "canceled"
                      ? "canceled"
                      : order.status === "processing"
                      ? "processing"
                      : "pending"
                  }
                >
                  {order.status}
                </td>
                <td>{new Date(order.datetime).toDateString()}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    );
  };
  return (
    <div className="layout">
      <div className="cat-list flex-box">
        <h3>Orders</h3>

        <select onChange={handleFilter}>
          <option value="all">All orders</option>
          <option value="pending">Pending orders</option>
          <option value="processing">Processing orders</option>
          <option value="complete">Complete orders</option>
          <option value="canceled">Canceled orders</option>
        </select>
        <p className="refresh-btn" onClick={CompRefresh}>
          <i className="fa fa-refresh"></i>
        </p>
      </div>
      <div className="list-view">
        {error && (
          <ErrorMessage
            message="): Error hard to find data"
            server_msg={error.message}
          />
        )}
        {message && (
          <div style={{ textAlign: "center" }}>
            {" "}
            <InlineMessage type={message.type} message={message.message} />
          </div>
        )}
        {loading && (
          <div style={{ marginTop: 30 }}>
            <Loading />
          </div>
        )}
        {!loading && <DataTable />}
      </div>
    </div>
  );
}
export default Orders;
