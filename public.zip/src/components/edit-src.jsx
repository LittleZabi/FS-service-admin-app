function Edit() {
  return (
    <div className="layout">
      <h3>Edit service</h3>
      <form>
        <label htmlFor="src-name">service name</label>
        <input type="text" name="" id="src-name" placeholder="Enter...." />
        <label htmlFor="src-category">select category</label>
        <select name="" id="src-category">
          <option defaultValue>select category...</option>
          <option value="value 1">category is smart phone</option>
        </select>
        <div className="flex-box">
          <label htmlFor="src-category">Deviler time(minuts)</label>
          <label htmlFor="src-price">select price</label>
        </div>
        <div className="flex-box">
          <input
            type="number"
            min="0"
            max="43200"
            step="5"
            id="src-devliver"
            placeholder="Enter...."
          />
          <input type="text" name="" id="src-price" placeholder="Enter...." />
        </div>
        <button type="button">
          <i className="fa fa-save"></i> Save
        </button>
      </form>
    </div>
  );
}
export default Edit;
