import axios from "axios";
import { useState } from "react";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { ShowModalAction } from "../store/actions";
import InlineMessage from "./inilne-message";
import Loading from "./loading";

function CatList() {
  const dispatch = useDispatch();
  const [List, setList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(false);
  const getCatList = async () => {
    setLoading(true);
    try {
      await axios.get("/admin/api/cat-list-details").then((res) => {
        const data = res.data;
        if (data.length > 0) {
          setList(data);
        } else {
          setMessage({ type: "alert", message: "empty no data found" });
        }
        setLoading(false);
      });
    } catch (error) {
      setLoading(false);
      setMessage({ type: "error", message: "Error: " + error.message });
    }
  };
  useEffect(() => {
    getCatList();
  }, [dispatch]);
  const DataTable = () => {
    return (
      <table>
        {List.length < 1 ? (
          <h3 className="empty-list">category list is empty</h3>
        ) : (
          <thead>
            <tr>
              <th>ID</th>
              <th>Category</th>
              <th>Service type</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
        )}
        <tbody>
          {List.map((cat) => {
            return (
              <tr
                key={cat.id}
                onClick={() => dispatch(ShowModalAction("EditCat", cat.slug))}
              >
                <td>{cat.id}</td>
                <td>{cat.category}</td>
                <td>{cat.service_type}</td>
                <td
                  style={
                    cat.active === 1
                      ? { background: "#afdbff", textAlign: "center" }
                      : { background: "#f3b49d", textAlign: "center" }
                  }
                >
                  {" "}
                </td>
                <td>{new Date(cat.date).toDateString()}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    );
  };
  return (
    <div className="layout">
      <div className="cat-list flex-box">
        <h3>Categories</h3>
        <div className="flex-box" style={{ alignItems: "center" }}>
          <p
            label="Refresh"
            className="refresh-btn"
            onClick={() => {
              getCatList();
            }}
          >
            <i className="fa fa-refresh"></i>
          </p>
          <button
            type="button"
            className="add-category"
            onClick={() => {
              dispatch(ShowModalAction("NewCatModel"));
            }}
          >
            <i className="fa fa-plus"></i>add category
          </button>
        </div>
      </div>
      <div className="list-view">
        {loading && <Loading />}
        {!loading && message && (
          <InlineMessage message={message.message} type={message.type} />
        )}
        {!loading && List.length > 0 && <DataTable />}
      </div>
    </div>
  );
}
export default CatList;
