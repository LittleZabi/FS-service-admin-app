import { Link } from "react-router-dom";
const SideBar = () => {
  return (
    <div className="admin-side">
      <ul className="admin-side-ul">
        <li>
          <Link to="/admin/">
            <i className="fa fa-bar-chart"></i>Dashboard
          </Link>
          <Link to="/admin/new">
            <i className="fa fa-plus"></i>Add service
          </Link>
          <Link to="/admin/list">
            <i className="fa fa-list"></i>Services list
          </Link>
          <Link to="/admin/cat-list">
            <i className="fa fa-list-alt"></i>Categories
          </Link>
          <Link to="/admin/srvc-inputs">
            <i className="fa fa-file-alt"></i>Service Inputs
          </Link>
          <Link to="/admin/orders">
            <i className="fa fa-truck"></i>Orders
          </Link>
          <Link to="/admin/payments">
            <i className="fa fa-dollar"></i>Payments
          </Link>
          <Link to="/admin/users-list">
            <i className="fa fa-users"></i>Users
          </Link>
          <Link to="/admin/feebacks">
            <i className="fa fa-paper-plane"></i>Contacts
          </Link>
          <Link to="/admin/new-user">
            <i className="fa fa-user-plus"></i>Add User
          </Link>
          <Link to="/admin/def-labels">
            <i className="fa fa-edit"></i>Default Labels
          </Link>
        </li>
      </ul>
    </div>
  );
};
export default SideBar;
