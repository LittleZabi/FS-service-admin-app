import axios from "axios";
import { useEffect, useState } from "react";
const Dashboard = () => {
  const [orders, setOrders] = useState({
    total: 0,
    pending: 0,
    complete: 0,
    canceled: 0,
  });
  const [services, setServices] = useState({
    total: 0,
    active: 0,
    Deactive: 0,
  });
  const [categ, setCateg] = useState({
    total: 0,
    active: 0,
    Deactive: 0,
  });
  const [users, setUsers] = useState({
    total: 0,
    active: 0,
    Deactive: 0,
  });
  const [Contact, setContact] = useState({
    total: 0,
    active: 0,
    Deactive: 0,
  });
  const [Payments, setPayments] = useState({
    total: 0,
    unpaid: 0,
    paid: 0,
    canceled: 0,
  });

  const getData = async (table) => {
    await axios.get("/admin/api/get-dashboard/" + table).then((res) => {
      const response = res.data;
      const total = response.length;
      if (table === "contact") {
        let active = 0;
        let Deactive = 0;
        response.map((e) => {
          if (e.replied) active++;
          else Deactive++;
          return 1;
        });
        setContact({ total, active, Deactive });
      }
      if (table === "Users") {
        let active = 0;
        let Deactive = 0;
        response.map((e) => {
          if (e.activated) active++;
          else Deactive++;
          return 1;
        });
        setUsers({ total, active, Deactive });
      }
      if (table === "services_category") {
        let active = 0;
        let Deactive = 0;
        response.map((e) => {
          if (e.active) active++;
          else Deactive++;
          return 1;
        });
        setCateg({ total, active, Deactive });
      }
      if (table === "services_list") {
        let active = 0;
        let Deactive = 0;
        response.map((e) => {
          if (e.active) active++;
          else Deactive++;
          return 1;
        });
        setServices({ total, active, Deactive });
      }
      if (table === "orders") {
        let pending = 0;
        let complete = 0;
        let canceled = 0;
        response.map((e) => {
          if (e.status === "pending") pending++;
          if (e.status === "complete") complete++;
          if (e.status === "canceled") canceled++;
          return 1;
        });
        setOrders({ pending, total, complete, canceled });
      }
      if (table === "payments") {
        let pending = 0;
        let complete = 0;
        let canceled = 0;
        response.map((e) => {
          if (e.status === "pending") pending++;
          if (e.status === "complete") complete++;
          if (e.status === "canceled") canceled++;
          return 1;
        });
        setPayments({
          unpaid: pending,
          total,
          paid: complete,
          canceled,
        });
      }
    });
  };
  useEffect(() => {
    const tables = [
      "orders",
      "services_list",
      "services_category",
      "Users",
      "contact",
      "payments",
    ];
    tables.forEach((table) => {
      getData(table);
      return 1;
    });
  }, []);
  return (
    <div className="dashboard">
      <section className="layout">
        <div className="count">{orders.total}</div>
        <div className="details">
          <span className="name">Orders</span>
          <span className="active">Completed: {orders.complete}</span>
          <span className="deactive">Canceled: {orders.canceled}</span>
          <span className="dash-pending">Pending: {orders.pending}</span>
        </div>
      </section>
      <section className="layout">
        <div className="count">{Payments.total}</div>
        <div className="details">
          <span className="name">Payments</span>
          <span className="active">Paid: {Payments.paid}</span>
          <span className="deactive">canceled: {Payments.canceled}</span>
          <span className="dash-pending">Unpaid: {Payments.unpaid}</span>
        </div>
      </section>
      <section className="layout">
        <div className="count">{services.total}</div>
        <div className="details">
          <span className="name">Services</span>
          <span className="active">Active: {services.active}</span>
          <span className="deactive">Deactive: {services.Deactive}</span>
        </div>
      </section>
      <section className="layout">
        <div className="count">{categ.total}</div>
        <div className="details">
          <span className="name">Categories</span>
          <span className="active">Active: {categ.active}</span>
          <span className="deactive">Deactive: {categ.Deactive}</span>
        </div>
      </section>
      <section className="layout">
        <div className="count">{users.total}</div>
        <div className="details">
          <span className="name">Users</span>
          <span className="active">Active: {users.active}</span>
          <span className="deactive">Deactive: {users.Deactive}</span>
        </div>
      </section>
      <section className="layout">
        <div className="count">{Contact.total}</div>
        <div className="details">
          <span className="name">Messages</span>
          <span className="active">Readed: {Contact.active}</span>
          <span className="dash-pending">Unreaded: {Contact.Deactive}</span>
        </div>
      </section>
    </div>
  );
};
export default Dashboard;
