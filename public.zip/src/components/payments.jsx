import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { CatListViewAction, ShowModalAction } from "../store/actions";
import ErrorMessage from "./error-msg";
import Loading from "./loading";
import axios from "axios";
import InlineMessage from "./inilne-message";

function Payments() {
  const dispatch = useDispatch();
  const [PaymentList, setPaymentList] = useState([]);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(false);
  const [crncy_rate, setCrncRate] = useState(1);
  const getCrncRate = async (crnc) => {
    if (crnc !== "PKR") {
      const convert = crnc + "_PKR";
      let crnc_cookies = localStorage.getItem("currency");
      if (crnc_cookies) {
        crnc_cookies = JSON.parse(crnc_cookies);
        if (crnc_cookies[convert]) {
          setCrncRate(crnc_cookies[convert]);
          return 1;
        }
      }
      try {
        await axios
          .get(
            `https://free.currconv.com/api/v7/convert?q=${convert}&compact=ultra&apiKey=fd0f4dc25bac27167fb8`
          )
          .then((res) => {
            if (res.data[convert]) {
              const value = res.data[convert];
              setCrncRate(value);
              localStorage.setItem("currency", JSON.stringify(res.data));
            } else {
              setCrncRate(1);
            }
          });
      } catch (error) {
        setCrncRate(1);
        console.warn("Currency can't converting due to: ", error.message);
      }
    }
  };
  const getRequest = async () => {
    setMessage(false);
    try {
      setLoading(true);
      await axios.get("/admin/api/payment-request-list").then((res) => {
        if (res.data.length > 0) {
          setPaymentList(res.data);
          const crnc = res.data[0].currency;
          getCrncRate(crnc);
        } else {
          setPaymentList([]);
          setMessage({
            type: "alert",
            message: "There is no Payment Request!",
          });
        }
        setLoading(false);
      });
    } catch (error) {
      setLoading(false);
      setError({ message: error.message });
    }
  };
  const CompRefresh = () => {
    getRequest();
  };
  useEffect(() => {
    getRequest();
    dispatch(CatListViewAction());
  }, [dispatch]);
  const DataTable = () => {
    return (
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>username</th>
            <th>Email</th>
            <th>Request Amount</th>
            <th>User Current Balance</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>

        <tbody>
          {PaymentList.map((order) => {
            return (
              <tr
                key={order.id}
                onClick={() =>
                  dispatch(ShowModalAction("pay-req-view", order.slug))
                }
              >
                <td>{order.id}</td>
                <td>{order.firstname + " " + order.lastname}</td>
                <td>{order.email}</td>
                <td style={{ fontWeight: "bold" }}>
                  {order.amount * crncy_rate +
                    (order.currency === "USD" ? "$" : order.currency)}
                </td>
                <td style={{ fontWeight: "bold" }}>
                  {order.crnt_balance * crncy_rate + " PKR"}
                </td>
                <td
                  className={
                    order.status === "complete"
                      ? "complete"
                      : order.status === "canceled"
                      ? "canceled"
                      : order.status === "processing"
                      ? "processing"
                      : "pending"
                  }
                >
                  {order.status}
                </td>
                <td>{new Date(order.datetime).toDateString()}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    );
  };
  return (
    <div className="layout">
      <div className="cat-list flex-box">
        <h3>Payment Request</h3>
        <p className="refresh-btn" onClick={CompRefresh}>
          <i className="fa fa-refresh"></i>
        </p>
      </div>
      <div className="list-view">
        {error && (
          <ErrorMessage
            message="): Error hard to find data"
            server_msg={error.message}
          />
        )}
        {message && (
          <div style={{ textAlign: "center" }}>
            {" "}
            <InlineMessage type={message.type} message={message.message} />
          </div>
        )}
        {loading && (
          <div style={{ marginTop: 30 }}>
            <Loading />
          </div>
        )}
        {!loading && <DataTable />}
      </div>
    </div>
  );
}
export default Payments;
