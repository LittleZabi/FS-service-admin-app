import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import InlineMessage from "../../components/inilne-message";
import Loading from "../../components/loading";
import { MessageAction, ShowModalAction } from "../../store/actions";
function UserEdit({ ModalPayload }) {
  const userSlug = ModalPayload.payload.data;
  const [Alert, setAlert] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState([]);
  const dispatch = useDispatch();

  const getUser = async () => {
    await axios.get("/admin/api/user-view/" + userSlug).then((res) => {
      console.log("response: ", res.data);
      setFormData(res.data);
    });
  };
  useEffect(() => {
    getUser();
  }, []);

  const SendData = async (userData) => {
    setLoading(true);
    try {
      await axios
        .post("/admin/api/update-user/", { formData: userData })
        .then((res) => {
          res = res.data.condition;
          if (res === "updated") {
            dispatch(MessageAction("success", "successfully Updated!"));
            setTimeout(() => {
              dispatch(ShowModalAction("user-view", userData.slug));
            }, 1000);
          } else {
            setAlert({
              type: "alert",
              message: "error on updating profile please try again later!",
            });
          }

          setLoading(false);
        });
    } catch {
      setLoading(false);
      setAlert({
        type: "error",
        message: "something going wrong please try again!",
      });
    }
  };
  const handleForm = (event) => {
    event.preventDefault();
    const email = event.target["email-address"].value;
    const password = event.target["password"].value;
    const phone = event.target["phone"].value;
    const passwordAgain = event.target["password-again"].value;
    const firstname = event.target["first-name"].value;
    const lastname = event.target["last-name"].value;
    const address1 = event.target["address-1"].value;
    const address2 = event.target["address-2"].value;
    const country = event.target["country"].value;
    const state = event.target["state"].value;
    const city = event.target["city"].value;
    const postal = event.target["zip"].value;
    const slug = event.target["slug"].value;
    const currency = event.target["currency"].value;
    setAlert(false);
    setFormData([
      {
        firstname,
        lastname,
        phone,
        password,
        address1,
        address2,
        country,
        state,
        city,
        postal,
        slug,
        currency,
        email,
      },
    ]);
    if (password !== "") {
      if (passwordAgain !== "") {
        if (password !== passwordAgain) {
          setAlert({
            type: "alert",
            message: "password not matched!",
          });
          return;
        }
      } else {
        setAlert({
          type: "alert",
          message: "Enter password again or clear first password input!",
        });
        return;
      }
    }
    if (email === "") {
      setAlert({
        type: "alert",
        message: "Enter Email address!",
      });
    } else if (firstname === "" || lastname === "") {
      setAlert({
        type: "alert",
        message: "Enter firstname and lastname!",
      });
    } else if (address1 === "") {
      setAlert({
        type: "alert",
        message: "Please Enter Addresses!",
      });
    } else if (country === "") {
      setAlert({
        type: "alert",
        message: "Please Enter country name!",
      });
    } else {
      SendData({
        firstname,
        email,
        phone,
        lastname,
        address1,
        address2,
        country,
        state,
        city,
        postal,
        slug,
        currency,
        password,
      });
    }
  };
  const BillingInfo = ({ user }) => {
    return (
      <>
        <h3 style={{ margin: 5 }}>Edit User</h3>
        <label>Enter Email address.</label>
        <input
          type="email"
          id="email-address"
          defaultValue={user.email}
          placeholder="Email address..."
        />
        <label>Phone number</label>
        <input
          type="text"
          id="phone"
          defaultValue={user.phone}
          placeholder="Phone number..."
        />
        <div className="flex-box">
          <label>Change password.</label>
          <label>password again.</label>
        </div>
        <div className="flex-box">
          <input type="text" id="password" placeholder="Enter password..." />
          <input
            type="text"
            id="password-again"
            placeholder="Enter password again..."
          />
        </div>
        <small>
          <b>
            Password: keeping empty it's mean you don't change the password!
          </b>
        </small>
        <div className="flex-box">
          <label>Enter firstname.</label>
          <label>Enter Lastname</label>
        </div>
        <div className="flex-box">
          <input
            type="text"
            id="first-name"
            defaultValue={user.firstname}
            placeholder="First Name..."
          />
          <input
            type="text"
            name="last-name"
            id="last-name"
            defaultValue={user.lastname}
            placeholder="Last Name..."
          />
        </div>
        <label htmlFor="currency" className="form-labels">
          Select Currency.
        </label>
        <select name="currency" id="currency">
          <option value={user.currency} defaultValue>
            {user.currency}
          </option>
          <option value="PKR">PKR (Pakistani Rupee)</option>
          <option value="USD">USD (Dollar)</option>
          <option value="AFN">AFN (Afghani)</option>
          <option value="AUD">AUD (Australian Dollar)</option>
          <option value="INR">INR (Indian Rupee</option>
          <option value="AZN">AZN (Azerbaijan manat)</option>
          <option value="BDT">BDT (Bangladeshi taka)</option>
          <option value="BHD">BHD (Bahraini dinar)</option>
          <option value="EUR">EUR (European euro)</option>
          <option value="BRL">BRL (Brazilian real)</option>
          <option value="CAD">CAD (Canadian dollar)</option>
          <option value="CNY">CNY (Chinese Yuan Renminbi)</option>
          <option value="EGP">EGP (Egyptian pound)</option>
          <option value="IDR">IDR (Indonesian rupiah)</option>
          <option value="IRR">IRR (Iranian rial)</option>
          <option value="IQD">IQD (Iraqi dinar)</option>
          <option value="ILS">ILS (Israeli new shekel)</option>
          <option value="JPY">JPY (Japanese yen)</option>
          <option value="KWD">KWD (Kuwaiti dinar)</option>
        </select>
        <label> Enter your Residence Address.</label>
        <input
          type="text"
          id="address-1"
          defaultValue={user.address1}
          placeholder="Residence Address..."
        />

        <label> Enter your Secondary Address (optional).</label>
        <input
          type="text"
          id="address-2"
          defaultValue={user.address2}
          placeholder="Secondary Address..."
        />

        <div className="flex-box">
          <label>Your Country name.</label>
          <label>State/Province name.</label>
        </div>
        <div className="flex-box">
          <input
            type="text"
            id="country"
            defaultValue={user.country}
            placeholder="country name..."
          />
          <input id="state" defaultValue={user.state} placeholder="State..." />
        </div>
        <div className="flex-box">
          <label>Enter City name.</label>
          <label>Zip/Postal Code.</label>
        </div>
        <div className="flex-box">
          <input
            defaultValue={user.city}
            name="city"
            id="city"
            placeholder="city name..."
          />
          <input
            name="zip"
            id="zip"
            defaultValue={user.postal}
            placeholder="Zip/Postal Code..."
          />
        </div>
      </>
    );
  };
  return (
    <>
      <div className="layout">
        <div className="srvc-list-view-modal">
          <div style={{ textAlign: "center" }}>
            {Alert && (
              <InlineMessage type={Alert.type} message={Alert.message} />
            )}
          </div>
          {formData.map((user) => {
            return (
              <form key="1" onSubmit={handleForm}>
                <input type="hidden" id="slug" value={user.slug} />
                <BillingInfo user={user} />

                <br />
                {loading && <Loading />}
                {!loading && (
                  <button type="submit">
                    <i className="fa fa-save"></i>
                    {" save"}{" "}
                  </button>
                )}
              </form>
            );
          })}
        </div>
      </div>
    </>
  );
}
export default UserEdit;
