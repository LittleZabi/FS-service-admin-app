const Logout = () => {
  const handleLog = () => {
    localStorage.removeItem("admin-user");
    window.location.href = "/admin/login";
  };
  return (
    <div className="logout layout">
      <h3>Logout from admin session!</h3>
      <button onClick={handleLog}>Logout</button>
    </div>
  );
};
export default Logout;
