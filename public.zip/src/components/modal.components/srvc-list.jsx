import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { service_cat_list, SrvclistAction } from "../../store/actions";
import { HIDE_MODAL } from "../../store/constants";
import InlineMessage from "../inilne-message";
import Loading from "../loading";

const SrvcListView = ({ ModalPayload }) => {
  const [loading, setLoading] = useState(false);
  const [lineMessage, setLineMessage] = useState(false);
  const [src_list_view, setSrcListView] = useState({});
  const dispatch = useDispatch();
  const category_list = useSelector((state) => state.SrvcCatList);
  const [message, setMessage] = useState(false);

  const src_req = async (slug) => {
    try {
      setLoading(true);
      const { data } = await axios.get("/admin/api/srvc-list-view/" + slug);
      setLoading(false);
      if (data.length > 0) {
        setSrcListView(data[0]);
      } else {
        setLineMessage({
          type: "alert",
          message: "Data did not retrived from db.",
        });
      }
    } catch {
      setLoading(false);
      setLineMessage({
        type: "error",
        message: ":( Error occured during fetching data!",
      });
      return {};
    }
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    const service_name = event.target["src-name"].value;
    const description = event.target["src-desc"].value;
    const status = event.target["src-status"].checked;
    const category = event.target["src-category"].value;
    const price = event.target["src-price"].value;
    const src_slug = event.target["src-slug"].value;
    const deliver = event.target["src-deliver"].value;
    const srvc_input1 = event.target["src-input1"].value;
    const srvc_input2 = event.target["src-input2"].value;
    const srvc_input3 = event.target["src-input3"].value;
    const srvc_input4 = event.target["src-input4"].value;
    if (service_name === "" || service_name.length < 6) {
      setMessage({
        type: "alert",
        message: "Enter service name(name must be greater than 6 characters).",
      });
    } else if (
      srvc_input1 === "" &&
      srvc_input2 === "" &&
      srvc_input3 === "" &&
      srvc_input4 === ""
    ) {
      setMessage({
        type: "alert",
        message:
          "All inputs is empty in the case client can't set a order with zero information!",
      });
    } else if (category === "") {
      setMessage({
        type: "alert",
        message:
          "Select a category(if category not exist you can use default category).",
      });
    } else {
      const service_data = {
        service_name,
        category,
        price,
        deliver,
        status,
        description,
        src_slug,
        srvc_input1,
        srvc_input2,
        srvc_input3,
        srvc_input4,
      };
      const sendRequest = async () => {
        try {
          setLoading(true);
          await axios
            .post(`/admin/api/update-service/`, { service_data })
            .then((response) => {
              setLoading(false);
              const res = response.data;
              if (res === "success") {
                setMessage({
                  message: "Service Updated successfuly!",
                  type: "success",
                });
                let modal = document.querySelector(".blue-modal");
                modal.classList.add("modal-close");
                setTimeout(() => {
                  dispatch({ type: HIDE_MODAL });
                }, 300);
                dispatch(SrvclistAction());
              }
            });
        } catch {
          setLoading(false);
          setMessage({
            message: "Something going wrong please try again later!",
            type: "error",
          });
        }
      };
      sendRequest();
    }
  };
  const handleDelete = (slug) => {
    const deleteSrc = async () => {
      setLoading(true);
      await axios.get("/admin/api/delete-srvc/" + slug).then((res) => {
        setMessage({
          message: "Service Deleted successfuly!",
          type: "success",
        });
        let modal = document.querySelector(".blue-modal");
        modal.classList.add("modal-close");
        setTimeout(() => {
          dispatch({ type: HIDE_MODAL });
        }, 300);
        dispatch(SrvclistAction());
      });
    };
    deleteSrc();
  };
  useEffect(() => {
    src_req(ModalPayload.payload.data);
    dispatch(service_cat_list());
  }, [dispatch]);

  return (
    <div className="layout">
      {loading && <Loading />}
      {lineMessage && (
        <div style={{ textAlign: "center" }}>
          <InlineMessage
            type={lineMessage.type}
            message={lineMessage.message}
          />
        </div>
      )}

      <div className="srvc-list-view-modal">
        {!loading && (
          <form onSubmit={handleSubmit}>
            <h3 style={{ margin: 0 }}>{src_list_view.service}</h3>
            <input
              type="hidden"
              id="src-slug"
              value={src_list_view.srvc_slug}
            />
            <p>
              you can edit and save your service here. just click on
              <span
                className="alert"
                onClick={() => handleDelete(src_list_view.srvc_slug)}
              >
                {" "}
                Delete Now
              </span>{" "}
              to delete service permanently.
            </p>
            <label htmlFor="src-name">service name</label>
            <input
              type="text"
              defaultValue={src_list_view.service}
              id="src-name"
              placeholder="Enter...."
            />
            <label htmlFor="src-name">Description</label>
            <textarea
              name=""
              id="src-desc"
              defaultValue={src_list_view.description}
              placeholder="Enter description...."
            />

            <label htmlFor="src-category">select category</label>
            <div className="flex-box">
              <select name="" id="src-category">
                <option value={src_list_view.slug} selected>
                  {src_list_view.category}
                </option>
                {category_list.cat_list &&
                  category_list.cat_list.map((e, index) => {
                    return (
                      <option key={e.id} value={e.slug}>
                        {e.category}
                      </option>
                    );
                  })}
              </select>
            </div>

            <div className="flex-box">
              <label htmlFor="src-category">Deviler time(minuts)</label>
              <label htmlFor="src-price">select price</label>
            </div>
            <div className="flex-box">
              <input
                type="text"
                id="src-deliver"
                defaultValue={src_list_view.deli_time}
                placeholder="10-20 Minutes"
              />
              <input
                type="number"
                name=""
                step="1"
                min="0"
                id="src-price"
                defaultValue={src_list_view.price}
                placeholder="20$"
              />
            </div>
            <label>
              Service require data(information which required from the client
              for this service)
            </label>
            <label htmlFor="src-input1">required input-1</label>
            <input
              type="text"
              name=""
              defaultValue={src_list_view.input1}
              id="src-input1"
              placeholder="e.g Enter IMEI...."
            />
            <div className="flex-box">
              <label htmlFor="src-input2">required input-2</label>
              <label htmlFor="src-input3">required input-3</label>
            </div>
            <div className="flex-box">
              <input
                type="text"
                id="src-input2"
                defaultValue={src_list_view.input2}
                placeholder="e.g Enter card number..."
              />
              <input
                type="text"
                id="src-input3"
                defaultValue={src_list_view.input3}
                placeholder="e.g Enter wildcard number..."
              />
            </div>
            <div className="flex-box">
              <label htmlFor="src-input4">required input-4</label>
            </div>
            <div className="flex-box">
              <input
                type="text"
                id="src-input4"
                defaultValue={src_list_view.input4}
                placeholder="e.g Enter device ID number..."
              />
            </div>
            <div className="flex-box">
              <label htmlFor="src-status">active status</label>
              <input
                type="checkbox"
                id="src-status"
                defaultChecked={src_list_view.active}
              />
            </div>

            <button type="submit">
              <i className="fa fa-save"></i> Save
            </button>

            {message && (
              <InlineMessage type={message.type} message={message.message} />
            )}
          </form>
        )}
      </div>
    </div>
  );
};
export default SrvcListView;
