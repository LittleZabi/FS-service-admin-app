import axios from "axios";
import { useEffect, useState } from "react";
import Loading from "../loading";
import InlineMessage from "../inilne-message";
import { currencyExchangeAction, MessageAction } from "../../store/actions";
import { useDispatch, useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
export default function PaymentReqView({ ModalPayload }) {
  const payment_id = ModalPayload.payload.data;
  const [payment_details, setPaymentDetails] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(false);
  const [RechargeCond, setRecharge] = useState(false);
  const [newAmount, setNewAmount] = useState(1);
  const [CrncyToRate, setCrncyToRate] = useState(["PKR_PKR", 1]);
  const dispatch = useDispatch();
  // const ReconvertCrncy = async (convert) => {
  //   convert = convert.replace(/\s/g, "");
  //   if (convert !== "PKR_PKR") {
  //     let crnc_cookies = localStorage.getItem("currency");
  //     if (crnc_cookies) {
  //       crnc_cookies = JSON.parse(crnc_cookies);
  //       if (crnc_cookies[convert]) {
  //         setPKRTo(crnc_cookies[convert]);
  //         return 1;
  //       }
  //     }
  //     try {
  //       await axios
  //         .get(
  //           `https://free.currconv.com/api/v7/convert?q=${convert}&compact=ultra&apiKey=fd0f4dc25bac27167fb8`
  //         )
  //         .then((res) => {
  //           if (res.data[convert]) {
  //             const value = res.data[convert];
  //             setPKRTo(value);
  //             localStorage.setItem("currency", JSON.stringify(res.data));
  //           } else {
  //             setPKRTo(1);
  //           }
  //         });
  //     } catch (error) {
  //       setPKRTo(1);
  //       console.warn("Currency can't converting due to: ", error.message);
  //     }
  //   }
  // };
  // const getCrncRate = async (crnc) => {
  //   if (crnc !== "PKR") {
  //     const convert = (crnc + "_PKR").replace(/\s/g, "");
  //     let crnc_cookies = localStorage.getItem("currency");
  //     if (crnc_cookies) {
  //       crnc_cookies = JSON.parse(crnc_cookies);
  //       if (crnc_cookies[convert]) {
  //         setCrncRate(crnc_cookies[convert]);
  //         return 1;
  //       }
  //     }
  //     try {
  //       await axios
  //         .get(
  //           `https://free.currconv.com/api/v7/convert?q=${convert}&compact=ultra&apiKey=fd0f4dc25bac27167fb8`
  //         )
  //         .then((res) => {
  //           if (res.data[convert]) {
  //             const value = res.data[convert];
  //             setCrncRate(value);
  //             localStorage.setItem("currency", JSON.stringify(res.data));
  //             MessageAction(
  //               "alert",
  //               "currency is not exchanged try to do by self."
  //             );
  //           } else {
  //             setCrncRate(1);
  //           }
  //         });
  //     } catch (error) {
  //       setCrncRate(1);
  //       dispatch(
  //         MessageAction(
  //           "alert",
  //           "Currency can't converting due to: ",
  //           error.message
  //         )
  //       );
  //       console.warn("Currency can't converting due to: ", error.message);
  //     }
  //   }
  // };
  const ViewOrder = async () => {
    try {
      setLoading(true);
      await axios
        .get("/admin/api/payment-req-view/" + payment_id)
        .then((res) => {
          setLoading(false);
          if (res.data.condition === "success") {
            const userCr = res.data.payment_details[0].currency;
            dispatch(currencyExchangeAction("PKR_" + userCr, "pkr_from"));
            setNewAmount(res.data.payment_details[0].amount);
            dispatch(currencyExchangeAction(userCr + "_PKR", "pkr_to"));
            setPaymentDetails(res.data.payment_details);
          } else {
            setMessage({ type: "alert", message: "Order is not exist!" });
          }
        });
    } catch (error) {
      setLoading(false);
      setMessage({ type: "error", message: "Error: " + error.message });
    }
  };
  const handleCalc = (amount) => {
    setNewAmount(amount);
  };

  const crncy_red = useSelector((state) => state.CrncyExchangeRed);
  {
    let _crnt_rate = 1;
    let _crnt_symbol = "PKR";
    let crnc_action = "pkr_to";
    if (crncy_red.payload) {
      if (crncy_red.payload.currency) {
        let crnc = crncy_red.payload.currency;
        crnc_action = crncy_red.payload.action;
        _crnt_symbol = crnc[0].split("_")[1];
        _crnt_rate = crnc[1];
      }
    }
    useEffect(() => {
      if (crnc_action !== "pkr_from") {
        setCrncyToRate([_crnt_symbol, _crnt_rate]);
      }
    }, [crncy_red, _crnt_rate, _crnt_symbol, crnc_action]);
  }
  useEffect(() => {
    ViewOrder();
  }, []);
  const handleRequest = (action, slug) => {
    const email = document.querySelector("#pay-email").value;
    const user = document.querySelector("#pay-user").value;
    const ReqAmount = document.querySelector("#pay-amount").value;
    const currency = document.querySelector("#pay-currency").value;
    const username = document.querySelector("#pay-username").value;
    const RechAmount = document.querySelector("#pay-recharge-amount").value;
    const RechAmountActual = document.querySelector(
      "#pay-recharge-actual-amount"
    ).value;
    const reqSlug = document.querySelector("#pay-slug").value;

    const req_data = {
      email,
      user,
      ReqAmount,
      currency,
      username,
      RechAmount,
      reqSlug,
      RechAmountActual,
    };
    if (action === "recharge") {
      if (parseInt(RechAmountActual) !== 0 || RechAmountActual !== "0") {
        setMessage({ type: "success", message: "Recharging Credits..." });
        axios.post("/admin/api/set-payment", req_data).then((res) => {
          if (res.data.condition === "success") {
            setTimeout(() => {
              setRecharge(true);
              dispatch(
                MessageAction(
                  "success",
                  "User Credits Recharged Successfully! Email send to the user"
                )
              );
            }, 4000);
          }
        });
      } else {
        setMessage({ type: "alert", message: "Enter amount to recharge!" });
      }
    } else if (action === "cancel") {
      setMessage({ type: "success", message: "Canceling Payment request..." });
      axios.post("/admin/api/cancel-payment", req_data).then((res) => {
        if (res.data.condition === "success") {
          setTimeout(() => {
            setRecharge(true);
            dispatch(
              MessageAction(
                "success",
                "User Payment Request Canceled Successfully! Email send to the user"
              )
            );
          }, 4000);
        }
      });
    }
  };
  return (
    <>
      {payment_details.map((order) => {
        return (
          <div className="modal-view-item layout" key="1">
            {RechargeCond && <Navigate to="/admin/payments" replace={false} />}
            {/* <h3>Order View</h3> */}
            <span className="top-user-name">
              Payment Request from {order.firstname}{" "}
            </span>
            <span className="table-head">Client Informations.</span>
            <table>
              <thead>
                <tr>
                  <td></td>
                  <td></td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>payment ID</td>
                  <td>{order.id}</td>
                </tr>
                <tr>
                  <td>user email</td>
                  <td> {order.email}</td>
                </tr>
                <tr>
                  <td>Phone</td>
                  <td> {order.phone}</td>
                </tr>
                <tr>
                  <td>amount in PKR</td>
                  <td>{(order.amount * CrncyToRate[1]).toFixed(2) + " PKR"}</td>
                </tr>
                <tr>
                  <td>Original Amount</td>
                  <td>
                    {" "}
                    {order.amount}
                    {order.currency === "USD" ? " $" : order.currency}
                  </td>
                </tr>
                <tr>
                  <td>user Current balance</td>
                  <td> {order.crnt_balance + " PKR"}</td>
                </tr>

                <tr>
                  <td>username</td>
                  <td>{order.firstname + " " + order.lastname}</td>
                </tr>
                <tr>
                  <td>User Email</td>
                  <td>
                    <a
                      target="_blank"
                      rel="noreferrer"
                      href={"mailto:" + order.email}
                      style={{
                        fontSize: 16,
                        textTransform: "none",
                        color: "#ff8b00",
                      }}
                    >
                      {order.email}
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>User Phone</td>
                  <td>
                    <a href={"tel:" + order.phone}>{order.phone}</a>
                  </td>
                </tr>
              </tbody>
            </table>
            <br />
            {order.status === "complete" ? (
              <h3 style={{ textAlign: "center" }}>Order Completed!</h3>
            ) : order.status === "canceled" ? (
              <h3 style={{ textAlign: "center", color: "orangered" }}>
                This Order has been canceled!
              </h3>
            ) : (
              <h3 style={{ textAlign: "center", color: "#9c42ff" }}>
                On Pending!
              </h3>
            )}
            {!loading && (
              <div className="order-buttons">
                <h3>Recharge The amount</h3>
                <input type="hidden" id="pay-email" value={order.email} />
                <input type="hidden" id="pay-user" value={order.user} />
                <input type="hidden" id="pay-amount" value={order.amount} />
                <input type="hidden" id="pay-currency" value={order.currency} />
                <input type="hidden" id="pay-slug" value={order.slug} />
                <input
                  type="hidden"
                  id="pay-recharge-actual-amount"
                  defaultValue={(CrncyToRate[1] * newAmount).toFixed(2)}
                />
                <input
                  type="hidden"
                  id="pay-username"
                  value={order.firstname + " " + order.lastname}
                />

                <span className="curncy-badge">PKR</span>
                <input
                  type="number"
                  min="0"
                  id="pay-recharge-amount"
                  onChange={(e) => {
                    handleCalc(e.target.value);
                  }}
                  defaultValue={(newAmount * CrncyToRate[1]).toFixed(2)}
                  style={{
                    width: 165,
                    fontSize: 16,
                  }}
                />
                <button onClick={() => handleRequest("recharge", order.slug)}>
                  {order.status === "complete"
                    ? "Recharge Payment again!"
                    : "Recharge Payment"}
                </button>
                <br />
                <span>
                  <strong>
                    Order of{" "}
                    <i style={{ color: "dodgerblue" }}>
                      {order.amount.toFixed(2)}
                      {order.currency}
                    </i>{" "}
                    and{" "}
                    <i style={{ color: "dodgerblue" }}>
                      {" "}
                      {newAmount}
                      {" PKR"}
                    </i>{" "}
                    will be charged.
                  </strong>
                </span>
                <br />
                <button
                  onClick={() => handleRequest("cancel", order.slug)}
                  style={{ width: 220, background: "#ff4278" }}
                >
                  Cancel Payment Request
                </button>
              </div>
            )}
          </div>
        );
      })}
      <div style={{ margin: "-30px 30px 5px 35px" }}>
        {loading && (
          <>
            <br />
            <Loading />
          </>
        )}
        {message && (
          <InlineMessage type={message.type} message={message.message} />
        )}
      </div>
    </>
  );
}
