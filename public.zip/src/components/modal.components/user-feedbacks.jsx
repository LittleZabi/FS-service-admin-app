import axios from "axios";
import { useState } from "react";
import InlineMessage from "../inilne-message";
import Loading from "../loading";

export default function UserFeedbacks({ ModalPayload }) {
  const [loading, setLoading] = useState();
  const [message, setMessage] = useState();
  const user = ModalPayload.payload.data;
  const HandleFormInputs = async (e) => {
    e.preventDefault();
    const msg = e.target["email-msg"].value;
    setMessage({ type: "success", message: "Sending your message...." });
    if (msg.length > 15) {
      setLoading(true);
      try {
        await axios
          .post("/admin/api/contact-repy", {
            msg,
            username: user.username,
            email: user.email,
            slug: user.slug,
          })
          .then((res) => {
            if (res.data.condition === "success") {
              setTimeout(() => {
                setMessage({
                  type: "success",
                  message: "message send successfully....",
                });
                setLoading(false);
              }, 5000);
            } else {
              setLoading(false);
            }
          });
      } catch (error) {
        setMessage({
          type: "error",
          message: "Error: " + error.message,
        });
      }
    } else {
      setMessage({
        type: "alert",
        message: "Message can be maximum 15 chars....",
      });
    }
  };
  return (
    <div className="new-cat-modal">
      <div className="layout">
        <h3 style={{ padding: 0, margin: 0 }}>Message</h3>
        <span style={{ marginLeft: 20 }}>{user.text}</span>
        <br />
        <hr />
        <form onSubmit={HandleFormInputs}>
          <h3 style={{ padding: 0, margin: 0 }}>Send a reply</h3>
          <label htmlFor="cat-name">your message goes here.</label>
          <textarea
            style={{ padding: 10 }}
            defaultValue={"Hi' " + user.username + ".\n"}
            id="email-msg"
            placeholder="Enter you email message...."
          ></textarea>
          {loading && <Loading />}
          {message && (
            <InlineMessage type={message.type} message={message.message} />
          )}
          {!loading && (
            <button type="submit">
              <i className="fa fa-paper-plane"></i> send
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
