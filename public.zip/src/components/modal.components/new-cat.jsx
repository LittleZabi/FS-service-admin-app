import axios from "axios";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { CatListViewAction, service_cat_list } from "../../store/actions";
import { HIDE_MODAL } from "../../store/constants";
import InlineMessage from "../inilne-message";
import Loading from "../loading";

const AddNewCat = () => {
  const dispatch = useDispatch();
  const [alertState, setAlertState] = useState(false);
  const [loading, setLoading] = useState(false);
  const HandleFormInputs = (event) => {
    event.preventDefault();
    const cate_name = event.target["cate-name"].value;
    const cate_type = event.target["src-categ-type"].value;
    if (cate_name.length > 2) {
      setLoading(true);
      const sendRequest = async () => {
        try {
          await axios
            .post(`/admin/api/new-category/`, { cate_name, cate_type })
            .then((response) => {
              setLoading(false);
              const res = response.data.condition;
              if (res === "exist")
                setAlertState({
                  message: "category is already exist choose another name!",
                  type: "alert",
                });

              if (res === "success") {
                setAlertState({
                  message: "category added successfuly!",
                  type: "success",
                });
                dispatch(service_cat_list());
                dispatch(CatListViewAction());
                let modal = document.querySelector(".blue-modal");
                modal.classList.add("modal-close");
                setTimeout(() => {
                  dispatch({ type: HIDE_MODAL });
                }, 300);
              }
            });
        } catch {
          setLoading(false);
          setAlertState({
            message: "Something going wrong please try again later!",
            type: "error",
          });
        }
      };

      sendRequest();
    } else {
      setAlertState({
        message: "Category name must be greter 3 characters!",
        type: "alert",
      });
    }
  };
  return (
    <div className="new-cat-modal">
      <div className="layout">
        <form onSubmit={HandleFormInputs}>
          {loading && <Loading />}
          <h3>Add new category</h3>
          <label htmlFor="cat-name">category name</label>
          <input
            type="text"
            id="cate-name"
            placeholder="Enter category name..."
          />
          <label htmlFor="src-categ-type">Select catgory type</label>
          <select id="src-categ-type">
            <option value="imei">IMEI</option>
            <option value="server">SERVER</option>
            <option value="remote">REMOTE</option>
            <option value="other">other</option>
          </select>

          <button type="submit">
            <i className="fa fa-save"></i> Save
          </button>

          {alertState && (
            <InlineMessage
              message={alertState.message}
              type={alertState.type}
            />
          )}
        </form>
      </div>
    </div>
  );
};
export default AddNewCat;
