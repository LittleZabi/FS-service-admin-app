import axios from "axios";
import { useEffect, useState } from "react";
import Loading from "../loading";
import InlineMessage from "../inilne-message";
import { HIDE_MODAL } from "../../store/constants";
export default function OrderView({ ModalPayload }) {
  const order_id = ModalPayload.payload.data;
  const [order_details, setOrderDetails] = useState([]);
  const [service_details, setServiceDetails] = useState([{ id: 1 }]);
  const [user_details, setUserDetails] = useState([{ slug: 1 }]);
  const [discount_details, setDiscountDetails] = useState([{ discount: 1 }]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(false);
  const [ExMsg, setExMsg] = useState(false);
  const ViewOrder = async () => {
    try {
      setLoading(true);
      await axios.get("/admin/api/order-view/" + order_id).then((res) => {
        setLoading(false);
        if (res.data.condition === "success") {
          setServiceDetails(res.data.service_details);
          setUserDetails(res.data.user_details);
          setDiscountDetails(res.data.discount_details);
          setOrderDetails(res.data.order_details);
        } else if ("notExist") {
          setMessage({ type: "alert", message: "Order not exist!" });
        } else if ("UserNotExist") {
          setMessage({ type: "alert", message: "User is not found!" });
        } else if ("SrvcNotExist") {
          setMessage({ type: "alert", message: "Service not found!" });
        }
      });
    } catch (error) {
      setLoading(false);
      setMessage({ type: "error", message: "Error: " + error.message });
    }
  };
  useEffect(() => {
    ViewOrder();
  }, []);
  const handleActions = async (slug, action) => {
    setLoading(true);
    try {
      const clientMsg = document.querySelector("#client-message").value;
      const email = document.querySelector("#email-box").value;
      const name = document.querySelector("#name-box").value;
      const src_name = document.querySelector("#src-name").value;
      const order_id = document.querySelector("#order-id").value;
      const src_paid_price = document.querySelector("#src-paid-price").value;
      const src_order_status =
        document.querySelector("#src-order-status").value;
      const src_user = document.querySelector("#src-user").value;
      const data = {
        action,
        slug,
        clientMsg: clientMsg.length > 39 ? clientMsg : "",
        email,
        name,
        order_id,
        src_name,
        src_paid_price,
        src_user,
        src_order_status,
      };
      setMessage({ type: "alert", message: "Loading..." });
      await axios.post("/admin/api/order-action/", data).then((res) => {
        setTimeout(() => {
          setLoading(false);
          ViewOrder();
          if (action === "complete") {
            setExMsg({
              type: "success",
              message: "A order completed email send to the client!",
            });
          }
          setMessage({
            type: "success",
            message:
              "Successfully updated! action applied(" +
              action +
              ") if the page is not updated please refersh.",
          });
        }, 5000);
      });
    } catch (err) {
      setLoading(false);
      setMessage({
        type: "error",
        message: `Error occured try again later! ${err.message}`,
      });
    }
  };

  return (
    <>
      {order_details.map((order) => {
        return (
          <div className="modal-view-item layout" key="1">
            {/* <h3>Order View</h3> */}
            <span className="top-user-name">
              Order on: {new Date().toDateString(order.datetime)}{" "}
            </span>
            <span className="table-head">Client Informations.</span>
            <table>
              <thead>
                <tr>
                  <td></td>
                  <td></td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>order ID</td>
                  <td>{order.id}</td>
                </tr>
                <tr>
                  <td>service ID</td>
                  <td> {service_details[0].id}</td>
                </tr>
                <tr>
                  <td>user ID</td>
                  <td>{user_details[0].id}</td>
                </tr>
                <tr>
                  <td>service</td>
                  <td> {service_details[0].service}</td>
                </tr>

                <tr>
                  <td>services</td>
                  <td> {order.service_type}</td>
                </tr>
                <tr>
                  <td>Price</td>
                  <td>
                    {service_details[0].price}
                    {" PKR"}
                  </td>
                </tr>
                <tr>
                  <td>Discount</td>
                  <td>
                    {discount_details[0].discount}
                    {" PKR "}
                    {discount_details[0].category}
                    {" Rank"}
                  </td>
                </tr>
                <tr>
                  <td>Paid Price</td>
                  <td style={{ fontWeight: "bold" }}>
                    {order.paid}
                    {" PKR"}
                  </td>
                </tr>
                <tr>
                  <td>username</td>
                  <td>
                    {user_details[0].firstname + " " + user_details[0].lastname}
                  </td>
                </tr>
                <tr>
                  <td>User Email</td>
                  <td>
                    <a
                      target="_blank"
                      rel="noreferrer"
                      href={"mailto:" + user_details[0].email}
                      style={{
                        fontSize: 16,
                        textTransform: "none",
                        color: "#ff8b00",
                      }}
                    >
                      {user_details[0].email}
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>User Phone</td>
                  <td>
                    <a href={"tel:" + user_details[0].phone}>
                      {user_details[0].phone}
                    </a>
                  </td>
                </tr>
              </tbody>
            </table>
            <br />
            <br />
            <h4>User Entered data for this services.</h4>
            <table>
              <thead>
                <tr>
                  <th>Request input</th>
                  <th>User Entered</th>
                </tr>
              </thead>
              <tbody>
                {service_details[0].input1 !== "" ? (
                  <tr>
                    <td>{service_details[0].input1}</td>
                    <td>{order.input1 !== "" ? order.input1 : "Nill"}</td>
                  </tr>
                ) : (
                  ""
                )}
                {service_details[0].input2 !== "" ? (
                  <tr>
                    <td className="field-view">{order.input2}</td>
                    <td>{order.input2 !== "" ? order.input2 : "Nill"}</td>
                  </tr>
                ) : (
                  ""
                )}
                {service_details[0].input3 !== "" ? (
                  <tr>
                    <td className="field-view">{order.input3}</td>
                    <td className="field-input">
                      {order.input3 !== "" ? order.input3 : "Nill"}
                    </td>
                  </tr>
                ) : (
                  ""
                )}
              </tbody>
            </table>
            {order.status === "complete" ? (
              <h3 style={{ textAlign: "center" }}>Order Completed!</h3>
            ) : order.status === "canceled" ? (
              <h3 style={{ textAlign: "center", color: "orangered" }}>
                This is canceled order!
              </h3>
            ) : order.status === "processing" ? (
              <h3 style={{ textAlign: "center" }}>On Processing</h3>
            ) : (
              <h3 style={{ textAlign: "center", color: "orange" }}>
                On Pending!
              </h3>
            )}
            {ExMsg && (
              <InlineMessage type={ExMsg.type} message={ExMsg.message} />
            )}
            <div>
              <h5
                style={{ marginBottom: 5, fontSize: 14 }}
                htmlFor="client-message"
              >
                Leave a message for client(if length is less than 40 its will
                empty message considered).
              </h5>
              <textarea
                style={{
                  width: "98%",
                  fontWeight: "bold",
                  padding: "5px 10px",
                }}
                id="client-message"
                name=""
                placeholder="Enter your message for client here...."
                defaultValue={
                  "Hi' Dear " + user_details[0].firstname + ".\n    "
                }
              ></textarea>
              <input
                type="hidden"
                id="email-box"
                value={user_details[0].email}
              />
              <input
                type="hidden"
                id="name-box"
                value={user_details[0].firstname}
              />
              <input type="hidden" id="order-id" value={order.id} />
              <input
                type="hidden"
                id="src-name"
                value={service_details[0].service}
              />
              <input type="hidden" id="src-paid-price" value={order.paid} />
              <input type="hidden" id="src-order-status" value={order.status} />
              <input type="hidden" id="src-user" value={order.user} />
            </div>
            {!loading && (
              <div className="order-buttons">
                {order.status !== "canceled" && (
                  <button
                    className="canceled-bg"
                    onClick={() => handleActions(order.slug, "canceled")}
                  >
                    Cancel Order
                  </button>
                )}
                {order.status !== "complete" && (
                  <button
                    className="completed-bg"
                    onClick={() => handleActions(order.slug, "complete")}
                  >
                    Make Completed
                  </button>
                )}
                {order.status !== "pending" && (
                  <button
                    className="pending-bg"
                    onClick={() => handleActions(order.slug, "pending")}
                  >
                    Make On Pending
                  </button>
                )}
                {order.status !== "processing" && (
                  <button
                    className="pending-bg"
                    onClick={() => handleActions(order.slug, "processing")}
                  >
                    On Processing
                  </button>
                )}
              </div>
            )}
          </div>
        );
      })}
      <div style={{ margin: "-30px 30px 5px 35px" }}>
        {loading && (
          <>
            <br />
            <Loading />
          </>
        )}
        {message && (
          <InlineMessage type={message.type} message={message.message} />
        )}
      </div>
    </>
  );
}
