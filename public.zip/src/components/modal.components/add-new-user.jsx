import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import InlineMessage from "../../components/inilne-message";
import Loading from "../../components/loading";
import { MessageAction, ShowModalAction } from "../../store/actions";
function AddUser() {
  const [Alert, setAlert] = useState(false);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();

  const SendData = async (userData) => {
    setLoading(true);
    try {
      await axios
        .post("/admin/api/new-user/", { formData: userData })
        .then((res) => {
          res = res.data.condition;
          if (res === "success") {
            dispatch(MessageAction("success", "successfully Added!"));
            setAlert({
              type: "success",
              message: "User added successfully!",
            });
          } else {
            setAlert({
              type: "alert",
              message: "error on adding new user please try again later!",
            });
          }

          setLoading(false);
        });
    } catch {
      setLoading(false);
      setAlert({
        type: "error",
        message: "something going wrong please try again!",
      });
    }
  };
  const handleForm = (event) => {
    event.preventDefault();
    const email = event.target["email-address"].value;
    const password = event.target["password"].value;
    const phone = event.target["phone"].value;
    const passwordAgain = event.target["password-again"].value;
    const firstname = event.target["first-name"].value;
    const lastname = event.target["last-name"].value;
    const address1 = event.target["address-1"].value;
    const address2 = event.target["address-2"].value;
    const country = event.target["country"].value;
    const state = event.target["state"].value;
    const city = event.target["city"].value;
    const postal = event.target["zip"].value;
    const currency = event.target["currency"].value;
    setAlert(false);
    const data = [
      {
        firstname,
        lastname,
        password,
        phone,
        address1,
        address2,
        country,
        state,
        city,
        postal,
        currency,
        email,
      },
    ];
    if (password === "") {
      setAlert({
        type: "alert",
        message: "Password is empty!",
      });
    } else if (password !== passwordAgain) {
      setAlert({
        type: "alert",
        message: "password not matched!",
      });
    } else if (email === "") {
      setAlert({
        type: "alert",
        message: "Enter Email address!",
      });
    } else if (firstname === "" || lastname === "") {
      setAlert({
        type: "alert",
        message: "Enter firstname and lastname!",
      });
    } else if (address1 === "") {
      setAlert({
        type: "alert",
        message: "Please Enter Addresses!",
      });
    } else if (country === "") {
      setAlert({
        type: "alert",
        message: "Please Enter country name!",
      });
    } else {
      SendData(data[0]);
    }
  };
  const BillingInfo = () => {
    return (
      <>
        <h3 style={{ margin: 5 }}>Edit User</h3>
        <label>Enter Email address.</label>
        <input type="email" id="email-address" placeholder="Email address..." />
        <label>Phone number</label>
        <input type="text" id="phone" placeholder="Phone number..." />
        <div className="flex-box">
          <label>Enter password.</label>
          <label>password again.</label>
        </div>
        <div className="flex-box">
          <input type="text" id="password" placeholder="Enter password..." />
          <input
            type="text"
            id="password-again"
            placeholder="Enter password again..."
          />
        </div>
        <div className="flex-box">
          <label>Enter firstname.</label>
          <label>Enter Lastname</label>
        </div>
        <div className="flex-box">
          <input type="text" id="first-name" placeholder="First Name..." />
          <input
            type="text"
            name="last-name"
            id="last-name"
            placeholder="Last Name..."
          />
        </div>
        <label htmlFor="currency" className="form-labels">
          Select Currency.
        </label>
        <select name="currency" id="currency">
          <option defaultValue value="PKR">
            PKR (Pakistani Rupee)
          </option>
          <option value="USD">USD (Dollar)</option>
          <option value="AFN">AFN (Afghani)</option>
          <option value="AUD">AUD (Australian Dollar)</option>
          <option value="INR">INR (Indian Rupee</option>
          <option value="AZN">AZN (Azerbaijan manat)</option>
          <option value="BDT">BDT (Bangladeshi taka)</option>
          <option value="BHD">BHD (Bahraini dinar)</option>
          <option value="EUR">EUR (European euro)</option>
          <option value="BRL">BRL (Brazilian real)</option>
          <option value="CAD">CAD (Canadian dollar)</option>
          <option value="CNY">CNY (Chinese Yuan Renminbi)</option>
          <option value="EGP">EGP (Egyptian pound)</option>
          <option value="IDR">IDR (Indonesian rupiah)</option>
          <option value="IRR">IRR (Iranian rial)</option>
          <option value="IQD">IQD (Iraqi dinar)</option>
          <option value="ILS">ILS (Israeli new shekel)</option>
          <option value="JPY">JPY (Japanese yen)</option>
          <option value="KWD">KWD (Kuwaiti dinar)</option>
        </select>
        <label> Enter Residence Address.</label>
        <input type="text" id="address-1" placeholder="Residence Address..." />

        <label> Enter Secondary Address (optional).</label>
        <input type="text" id="address-2" placeholder="Secondary Address..." />

        <div className="flex-box">
          <label>Country name.</label>
          <label>State/Province name.</label>
        </div>
        <div className="flex-box">
          <input type="text" id="country" placeholder="country name..." />
          <input id="state" placeholder="State..." />
        </div>
        <div className="flex-box">
          <label>City name.</label>
          <label>Zip/Postal Code.</label>
        </div>
        <div className="flex-box">
          <input name="city" id="city" placeholder="city name..." />
          <input name="zip" id="zip" placeholder="Zip/Postal Code..." />
        </div>
      </>
    );
  };
  return (
    <>
      <div className="layout">
        <div className="srvc-list-view-modal">
          <div style={{ textAlign: "center" }}>
            {Alert && (
              <InlineMessage type={Alert.type} message={Alert.message} />
            )}
          </div>
          <form keepDirtyOnReinitialize={true} key="1" onSubmit={handleForm}>
            <BillingInfo />
            <br />
            {loading && <Loading />}
            {!loading && (
              <button type="submit">
                <i className="fa fa-save"></i>
                {" save"}{" "}
              </button>
            )}
          </form>
        </div>
      </div>
    </>
  );
}
export default AddUser;
