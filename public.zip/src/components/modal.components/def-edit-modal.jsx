import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { CatListViewAction } from "../../store/actions";
import { HIDE_MODAL } from "../../store/constants";
import InlineMessage from "../inilne-message";
import Loading from "../loading";

const DefLableEdit = ({ ModalPayload }) => {
  const dispatch = useDispatch();
  const [defLabels, setDefLabelsView] = useState({});
  const [alertState, setAlertState] = useState(false);
  const [loading, setLoading] = useState(false);
  const getDefLabels = async (slug) => {
    await axios.get("/admin/api/get-def-label/" + slug).then((response) => {
      setDefLabelsView(response.data[0]);
    });
  };
  useEffect(() => {
    getDefLabels(ModalPayload.payload.data);
  }, [ModalPayload.payload.data]);
  const HandleFormInputs = (event) => {
    event.preventDefault();
    const DefValue = event.target["def-value"].value;
    const id = event.target["def-id"].value;
    setLoading(true);
    const sendRequest = async () => {
      try {
        const cat_data = {
          DefValue,
          id,
        };
        await axios
          .post("/admin/api/update-DefLabels/", { cat_data })
          .then((response) => {
            setLoading(false);
            const res = response.data.condition;
            if (res === "success") {
              setAlertState({
                message: "category updated successfuly!",
                type: "success",
              });
              let modal = document.querySelector(".blue-modal");
              modal.classList.add("modal-close");
              setTimeout(() => {
                dispatch({ type: HIDE_MODAL });
              }, 300);
              dispatch(CatListViewAction());
            }
          });
      } catch {
        setLoading(false);
        setAlertState({
          message: "Something going wrong please try again later!",
          type: "error",
        });
      }
    };

    sendRequest();
  };
  const handleDelete = (slug) => {
    const deleteDefLabel = async () => {
      setAlertState({
        message:
          "You can't Delete default labels instead of deleting keep it blank.",
        type: "alert",
      });
      //   setLoading(true);
      //   await axios.get("/admin/api/delete-def-label/" + slug).then((res) => {
      //     console.log(res.data);
      //     if (res.data === "success") {
      //       setAlertState({
      //         message: "Default Label deleted successfuly!",
      //         type: "success",
      //       });
      //       let modal = document.querySelector(".blue-modal");
      //       modal.classList.add("modal-close");
      //       setTimeout(() => {
      //         dispatch({ type: HIDE_MODAL });
      //       }, 300);
      //       dispatch(CatListViewAction());
      //     }
      //   });
    };
    deleteDefLabel();
  };
  return (
    <div className="new-cat-modal">
      <div className="layout">
        {loading && <Loading />}
        {!loading && (
          <form onSubmit={HandleFormInputs}>
            <h3>Edit Default Label</h3>

            <p>
              Edit or delete your default Values and Labels.
              <br />
              Delete your Default Key
              <span
                className="alert"
                onClick={() => handleDelete(defLabels.id)}
              >
                {" "}
                Delete Now
              </span>
            </p>
            <input type="hidden" id="def-id" defaultValue={defLabels.id} />

            <label htmlFor="cat-name">Value</label>
            <input
              type="text"
              id="def-value"
              defaultValue={defLabels.value}
              placeholder="Enter value here..."
            />

            <button type="submit">
              <i className="fa fa-save"></i> Save
            </button>

            {alertState && (
              <InlineMessage
                message={alertState.message}
                type={alertState.type}
              />
            )}
          </form>
        )}
      </div>
    </div>
  );
};
export default DefLableEdit;
