import axios from "axios";
import { useEffect, useState } from "react";
import Loading from "../loading";
import InlineMessage from "../inilne-message";
import { MessageAction, ShowModalAction } from "../../store/actions";
import { useDispatch } from "react-redux";
import { HIDE_MODAL } from "../../store/constants";
export default function UserView({ ModalPayload }) {
  const user_id = ModalPayload.payload.data;
  const [user_status, setUserStatus] = useState(1);
  const [user, setUser] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(false);
  const dispatch = useDispatch();
  const ViewUser = async () => {
    try {
      setLoading(true);
      await axios.get("/admin/api/user-view/" + user_id).then((res) => {
        setLoading(false);
        if (res.data.length > 0) {
          setUser(res.data);
          setUserStatus(res.data[0].activated);
        } else {
          setMessage({ type: "alert", message: "user is not found!" });
        }
      });
    } catch (error) {
      setLoading(false);
      setMessage({ type: "error", message: "Error: " + error.message });
    }
  };
  useEffect(() => {
    ViewUser();
  }, []);
  const handleAction = async (action, slug) => {
    await axios
      .get("/admin/api/user-action/" + action + "/" + slug)
      .then((res) => {
        let modal = document.querySelector(".blue-modal");
        modal.classList.add("modal-close");
        setTimeout(() => {
          action === "delete"
            ? dispatch(MessageAction("success", "Delete successfully..."))
            : action === "disable"
            ? dispatch(MessageAction("success", "Disabled successfully...."))
            : dispatch(MessageAction("success", "Enabled successfully...."));
          setTimeout(() => {
            dispatch({ type: HIDE_MODAL });
          }, 300);
        }, 1000);
      });
  };
  return (
    <>
      {user.map((user_) => {
        return (
          <div className="modal-view-item layout" key="1">
            <span className="top-user-name">
              {user_.firstname + " " + user_.lastname}
              <span> From {new Date().toDateString(user_.datetime)}</span>
            </span>
            <span className="table-head">user information</span>
            <table>
              <thead>
                <tr>
                  <td></td>
                  <td></td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  {/* <td>Avatar: </td>
                  <td className="image">
                    <a
                      target="_blank"
                      rel="noreferrer"
                      href={
                        user_.avatar !== ""
                          ? user_.avatar
                          : `/media/users/user1.png`
                      }
                      alt={user_.firstname}
                    >
                      <img
                        width={65}
                        src={
                          user_.avatar !== ""
                            ? user_.avatar
                            : `/media/users/user1.png`
                        }
                        alt=""
                      />
                    </a>
                  </td> */}
                </tr>
                <tr>
                  <td>Active Status: </td>
                  <td
                    style={
                      user_.activated === 1
                        ? { background: "#afdbff" }
                        : { background: "#f3b49d" }
                    }
                  ></td>
                  {/* <td></td> */}
                </tr>
                <tr>
                  <td>fullname: </td>
                  <td>{user_.firstname + " " + user_.lastname}</td>
                </tr>

                <tr>
                  <td>email address </td>
                  <td>
                    <a
                      target="_blank"
                      rel="noreferrer"
                      href={"mailto:" + user_.email}
                    >
                      {user_.email}
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>contact number </td>
                  <td>
                    <a
                      target="_blank"
                      rel="noreferrer"
                      href={"tel:" + user_.email}
                    >
                      {user_.phone}
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>Current Balance</td>
                  <td>
                    {user_.crnt_balance} {" PKR"}
                  </td>
                </tr>
                <tr>
                  <td>Total spent </td>
                  <td>
                    {user_.total_spent} {" PKR"}
                  </td>
                </tr>
                <tr>
                  <td>join date </td>
                  <td>{new Date().toDateString(user_.datetime)}</td>
                </tr>
                <tr>
                  <td>address 1 </td>
                  <td>{user_.address1}</td>
                </tr>
                <tr>
                  <td>address 2 </td>
                  <td>{user_.address2}</td>
                </tr>
                <tr>
                  <td>country </td>
                  <td>{user_.country}</td>
                </tr>
                <tr>
                  <td>state </td>
                  <td>{user_.state}</td>
                </tr>
                <tr>
                  <td>city </td>
                  <td>{user_.city}</td>
                </tr>
                <tr>
                  <td>postal </td>
                  <td>{user_.postal}</td>
                </tr>
              </tbody>
            </table>
            <button
              onClick={() => dispatch(ShowModalAction("user-edit", user_.slug))}
            >
              <i className="fa fa-edit"></i>
              Edit user
            </button>
            <button onClick={() => handleAction("delete", user_.slug)}>
              <i className="fa fa-trash"></i>
              Delete
            </button>
            {user_status === 1 ? (
              <button
                className="btn-2"
                onClick={() => handleAction("disable", user_.slug)}
              >
                Deactivate
              </button>
            ) : (
              <button onClick={() => handleAction("enable", user_.slug)}>
                Activate
              </button>
            )}
          </div>
        );
      })}
      <div style={{ margin: "10px 30px 5px 35px" }}>
        {loading && (
          <>
            <br />
            <Loading />
          </>
        )}
        {message && (
          <InlineMessage type={message.type} message={message.message} />
        )}
      </div>
    </>
  );
}
