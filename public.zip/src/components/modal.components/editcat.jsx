import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { CatListViewAction } from "../../store/actions";
import { HIDE_MODAL } from "../../store/constants";
import InlineMessage from "../inilne-message";
import Loading from "../loading";

const EditCat = ({ ModalPayload }) => {
  const dispatch = useDispatch();
  const [cat_details, setCatDetails] = useState({});
  const [alertState, setAlertState] = useState(false);
  const [notExist, setNotExist] = useState(false);
  const [loading, setLoading] = useState(false);
  const getCatDetails = async (slug) => {
    await axios.get("/admin/api/get-cat/" + slug).then((response) => {
      if (response.data.length > 0) {
        setCatDetails(response.data[0]);
      } else {
        setNotExist({
          message: "Category is not exist!",
          type: "alert",
        });
      }
    });
  };
  useEffect(() => {
    getCatDetails(ModalPayload.payload.data);
  }, [ModalPayload.payload.data]);
  const HandleFormInputs = (event) => {
    event.preventDefault();
    const cate_name = event.target["cate-name"].value;
    const cat_slug = event.target["cate-slug"].value;
    const cat_oldname = event.target["cate-oldname"].value;
    const cat_service_type = event.target["cate-service-type"].value;
    const cat_status = event.target["cat-status"].checked;
    if (cate_name.length > 2) {
      setLoading(true);
      const sendRequest = async () => {
        try {
          const cat_data = {
            cat_slug,
            cate_name,
            cat_status,
            cat_oldname,
            cat_service_type,
          };
          await axios
            .post(`/admin/api/update-category/`, { cat_data })
            .then((response) => {
              setLoading(false);
              const res = response.data.condition;
              if (res === "exist") {
                setAlertState({
                  message: "category is already exist choose another name!",
                  type: "alert",
                });
                return 0;
              } else if (res === "success") {
                setAlertState({
                  message: "category updated successfuly!",
                  type: "success",
                });
                let modal = document.querySelector(".blue-modal");
                modal.classList.add("modal-close");
                setTimeout(() => {
                  dispatch({ type: HIDE_MODAL });
                }, 300);
                dispatch(CatListViewAction());
              }
            });
        } catch {
          setLoading(false);
          setAlertState({
            message: "Something going wrong please try again later!",
            type: "error",
          });
        }
      };

      sendRequest();
    } else {
      setAlertState({
        message: "Category name must be greter 3 characters!",
        type: "alert",
      });
    }
  };
  const handleDelete = (slug) => {
    const deleteCat = async () => {
      setLoading(true);
      await axios.get("/admin/api/delete-cat/" + slug).then((res) => {
        console.log(res.data);
        if (res.data === "DefCatNotDel") {
          setLoading(false);
          setAlertState({
            message: "You can't delete default category!",
            type: "alert",
          });
        } else if (res.data === "success") {
          setAlertState({
            message: "Category deleted successfuly!",
            type: "success",
          });
          let modal = document.querySelector(".blue-modal");
          modal.classList.add("modal-close");
          setTimeout(() => {
            dispatch({ type: HIDE_MODAL });
          }, 300);
          dispatch(CatListViewAction());
        }
      });
    };
    deleteCat();
  };
  return (
    <div className="new-cat-modal">
      <div className="layout">
        {notExist && (
          <InlineMessage type={notExist.type} message={notExist.message} />
        )}
        {!notExist && (
          <>
            {loading && <Loading />}
            {!loading && (
              <form onSubmit={HandleFormInputs}>
                <h3>Add new category</h3>
                <p style={{ fontSize: 12 }} className="alert">
                  note: if category is deleted all services which connect with
                  this category will be changed to default category!.
                </p>
                <p>
                  you can edit and save your category here. just click on
                  <span
                    className="alert"
                    onClick={() => handleDelete(cat_details.slug)}
                  >
                    {" "}
                    Delete Now
                  </span>{" "}
                  to delete category permanently.
                </p>
                <input
                  type="hidden"
                  id="cate-oldname"
                  defaultValue={cat_details.category}
                />

                <input
                  type="hidden"
                  id="cate-slug"
                  defaultValue={cat_details.slug}
                />

                <label htmlFor="cat-name">category name</label>
                <input
                  type="text"
                  id="cate-name"
                  defaultValue={cat_details.category}
                  placeholder="Enter category name..."
                />
                <label htmlFor="cate-service-type">service type</label>
                <select id="cate-service-type">
                  <option
                    defaultChecked={
                      cat_details.service_type === "imei" ? true : false
                    }
                    defaultValue="imei"
                  >
                    IMEI
                  </option>
                  <option
                    selected={
                      cat_details.service_type === "server" ? true : false
                    }
                    defaultValue="server"
                  >
                    SERVER
                  </option>
                  <option
                    selected={
                      cat_details.service_type === "remote" ? true : false
                    }
                    defaultValue="remote"
                  >
                    Remote
                  </option>
                  <option
                    selected={
                      cat_details.service_type === "other" ? true : false
                    }
                    defaultValue="other"
                  >
                    other
                  </option>
                </select>
                <div className="flex-box">
                  <label htmlFor="src-status">active status</label>
                  <input
                    type="checkbox"
                    id="cat-status"
                    defaultChecked={cat_details.active}
                  />
                </div>
                <button type="submit">
                  <i className="fa fa-save"></i> Save
                </button>

                {alertState && (
                  <InlineMessage
                    message={alertState.message}
                    type={alertState.type}
                  />
                )}
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
};
export default EditCat;
