export default function ErrorMessage({ message, server_msg }) {
  return (
    <div className="container-error-msg">
      <div>
        <p>{message}</p>
        <span>ERROR: {server_msg}</span>
      </div>
    </div>
  );
}
