function InlineMessage({ type = "success", message }) {
  return (
    <div>
      <p className={"inline-alert " + type}>{message}</p>
    </div>
  );
}
export default InlineMessage;
