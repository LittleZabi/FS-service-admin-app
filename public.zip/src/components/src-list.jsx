import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ShowModalAction, SrvclistAction } from "../store/actions";
import ErrorMessage from "./error-msg";
import Loading from "./loading";

function List() {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(SrvclistAction());
  }, [dispatch]);
  const srvc_data = useSelector((state) => state.SrvcRed);
  const DataTable = () => {
    return (
      <table>
        {srvc_data.srvc_data.length < 1 ? (
          <h3 className="empty-list">services list is empty</h3>
        ) : (
          <thead>
            <tr>
              <th>ID</th>
              <th>Service</th>
              <th>Description</th>
              <th>Status</th>
              <th>Category</th>
              <th>Delivery time</th>
              <th>Price</th>
            </tr>
          </thead>
        )}
        <tbody>
          {srvc_data.srvc_data.map((srvc) => {
            return (
              <tr
                key={srvc.id}
                onClick={() =>
                  dispatch(ShowModalAction("SrvcListView", srvc.srvc_slug))
                }
              >
                <td>{srvc.id}</td>
                <td>{srvc.service}</td>
                <td>{srvc.description}</td>
                <td
                  style={
                    srvc.active === 1
                      ? { background: "#afdbff", textAlign: "center" }
                      : { background: "#f3b49d", textAlign: "center" }
                  }
                ></td>
                <td>
                  {srvc.category}({srvc.service_type})
                </td>
                <td>{srvc.deli_time} min</td>
                <td>${srvc.price}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    );
  };
  const CompRefresh = () => {
    dispatch(SrvclistAction());
  };
  return (
    <div className="layout">
      <div className="cat-list flex-box">
        <h3>Services</h3>
        <p className="refresh-btn" onClick={CompRefresh}>
          <i className="fa fa-refresh"></i>
        </p>
      </div>
      <div className="list-view">
        {srvc_data.loading ? (
          <Loading />
        ) : srvc_data.ER_Raise ? (
          <ErrorMessage
            message="): Error hard to find data"
            server_msg={srvc_data.ER_Raise}
          />
        ) : srvc_data.srvc_data ? (
          <DataTable />
        ) : (
          ""
        )}
      </div>
    </div>
  );
}
export default List;
