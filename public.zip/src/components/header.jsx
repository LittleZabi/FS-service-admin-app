import axios from "axios";
import { useEffect } from "react";
import { useState } from "react";
import { FaUser } from "react-icons/fa";
import { useDispatch } from "react-redux";
import { ShowModalAction } from "../store/actions";
const Header = () => {
  const dispatch = useDispatch();
  const [Results, setResults] = useState([[]]);
  const [letters, setLetters] = useState(false);
  const [User, SetUser] = useState([]);
  const getUser = () => {
    let user = localStorage.getItem("admin-user");
    if (user) {
      user = JSON.parse(user);
      SetUser(user);
    }
  };
  const GetResults = async (select, search) => {
    await axios.get(`/admin/api/search/${select}/${search}`).then((res) => {
      setResults([res.data, select]);
    });
  };
  const handleForm = () => {
    const search = document.querySelector("#search").value;
    const select = document.querySelector("#search-select").value;
    if (search.length > 0) {
      setLetters(true);
      GetResults(select, search);
    } else {
      setResults([[]]);
    }
  };
  const clearSearch = () => {
    setResults([[]]);

    setLetters(false);
  };
  useEffect(() => {
    getUser();
  }, []);
  return (
    <header>
      <div className="page-view inner-header">
        <div className="logo">
          <h3>FSUnlocker</h3>
        </div>
        <div>
          <div className="search-sec">
            <form>
              <input
                onKeyUp={handleForm}
                type="text"
                id="search"
                placeholder="Search here..."
              />
              <div className="search-clear-btn" onClick={clearSearch}>
                <i className={letters === true ? "fa fa-times" : ""}></i>
              </div>
              <select id="search-select" onChange={handleForm}>
                <option value="orders">Orders</option>
                <option value="users">Users</option>
                <option value="categories">Categories</option>
                <option value="service">Services</option>
              </select>
            </form>
            {Results[0].length < 1 ? (
              ""
            ) : (
              <div className="search-results">
                {Results[0].map((res, i) => {
                  if (Results[1] === "orders") {
                    return (
                      <span
                        key={i}
                        onClick={() =>
                          dispatch(ShowModalAction("OrderView", res.slug))
                        }
                      >
                        <small>{res.id}: </small>
                        {res.firstname + " " + res.lastname}
                        <br />
                        <small>service: {res.service}</small>
                      </span>
                    );
                  }
                  if (Results[1] === "users") {
                    return (
                      <span
                        key={i}
                        onClick={() =>
                          dispatch(ShowModalAction("user-view", res.slug))
                        }
                      >
                        <small>{res.id}: </small>
                        {res.firstname + " " + res.lastname}
                        <br />
                        <small>Email: {res.email}</small>
                      </span>
                    );
                  }
                  if (Results[1] === "categories") {
                    return (
                      <span
                        key={i}
                        onClick={() =>
                          dispatch(ShowModalAction("EditCat", res.slug))
                        }
                      >
                        <small>{res.id}: </small>
                        {res.category}
                        <br />
                        <small>Service: {res.service_type}</small>
                      </span>
                    );
                  }
                  if (Results[1] === "service") {
                    return (
                      <span
                        key={i}
                        onClick={() =>
                          dispatch(
                            ShowModalAction("SrvcListView", res.srvc_slug)
                          )
                        }
                      >
                        <small>{res.id}: </small>
                        {res.service}
                        <br />
                      </span>
                    );
                  }
                  return <span>search not found...</span>;
                })}
              </div>
            )}
          </div>
        </div>
        <div>
          <ul>
            <li onClick={() => dispatch(ShowModalAction("NavBar"))}>
              <span className="header-username">{User.username}</span>
            </li>
            <li>
              <button
                name="Menu button"
                title="Reveal Menu"
                onClick={() => dispatch(ShowModalAction("NavBar"))}
                className="nav-menu-btn"
              >
                {<FaUser />}
              </button>
            </li>
          </ul>
        </div>
      </div>
    </header>
  );
};
export default Header;
