import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ShowModalAction, service_cat_list } from "../store/actions";
import InlineMessage from "./inilne-message";
import Loading from "./loading";

const NewPost = () => {
  const dispatch = useDispatch();
  const category_list = useSelector((state) => state.SrvcCatList);
  const [message, setMessage] = useState(false);
  const [LoadingState, SetLoadingState] = useState(false);
  const [InputValues, setInputsValues] = useState([
    { value: "" },
    { value: "" },
    { value: "" },
    { value: "" },
  ]);
  const getDefaults = async () => {
    axios.get("/admin/api/getDefaults/").then((res) => {
      if (res.data.length > 0) {
        setInputsValues(res.data);
      }
    });
  };
  useEffect(() => {
    getDefaults();
  }, []);

  useEffect(() => {
    dispatch(service_cat_list());
  }, [dispatch]);
  const handleSubmit = (event) => {
    event.preventDefault();
    const service_name = event.target["src-name"].value;
    const description = event.target["src-desc"].value;
    const category = event.target["src-category"].value;
    const price = event.target["src-price"].value;
    const deliver = event.target["src-deliver"].value;
    const srvc_input1 = event.target["src-input1"].value;
    const srvc_input2 = event.target["src-input2"].value;
    const srvc_input3 = event.target["src-input3"].value;
    const srvc_input4 = event.target["src-input4"].value;
    if (service_name === "" || service_name.length < 6) {
      setMessage({
        type: "alert",
        message: "Enter service name(name must be greater than 6 characters).",
      });
    } else if (
      srvc_input1 === "" &&
      srvc_input2 === "" &&
      srvc_input3 === "" &&
      srvc_input4 === ""
    ) {
      setMessage({
        type: "alert",
        message:
          "All inputs is empty in the case client can't set a order with zero information!",
      });
    } else if (category === "") {
      setMessage({
        type: "alert",
        message:
          "Select a category(if category not exist you can use default category).",
      });
    } else {
      const service_data = {
        service_name,
        category,
        price,
        deliver,
        description,
        srvc_input1,
        srvc_input2,
        srvc_input3,
        srvc_input4,
      };
      const sendRequest = async () => {
        try {
          SetLoadingState(true);
          await axios
            .post(`/admin/api/new-service/`, { service_data })
            .then((response) => {
              SetLoadingState(false);
              const res = response.data;
              if (res === "exist")
                setMessage({
                  message: "Service already exist with this name!",
                  type: "alert",
                });

              if (res === "success") {
                setMessage({
                  message: "Service added successfuly!",
                  type: "success",
                });
              }
            });
        } catch {
          SetLoadingState(false);
          setMessage({
            message: "Something going wrong please try again later!",
            type: "error",
          });
        }
      };
      sendRequest();
    }
  };
  return (
    <div className="layout">
      <h3>Add new service</h3>
      <form onSubmit={handleSubmit}>
        <label htmlFor="src-name">service name</label>
        <input type="text" name="" id="src-name" placeholder="Enter...." />
        <label htmlFor="src-name">Description</label>
        <textarea
          name=""
          id="src-desc"
          placeholder="Enter description...."
        ></textarea>
        <label htmlFor="src-category">select category</label>
        <div className="flex-box">
          <select name="" id="src-category">
            {category_list.cat_list &&
              category_list.cat_list.map((e, index) => {
                return (
                  <option
                    selected={index === 0 ? true : false}
                    key={e.id}
                    value={e.slug}
                  >
                    {e.category}
                  </option>
                );
              })}
          </select>
          <button
            type="button"
            className="add-category"
            onClick={() => {
              dispatch(ShowModalAction("NewCatModel"));
            }}
          >
            <i className="fa fa-plus"></i>add category
          </button>
        </div>
        <div className="flex-box">
          <label htmlFor="src-category">
            Deviler time(Declare time in minutes)
          </label>
          <label htmlFor="src-price">select price (only in PKR)</label>
        </div>
        <div className="flex-box">
          <input type="text" id="src-deliver" placeholder="e.g 10-20 Minutes" />
          <input
            type="number"
            step="1"
            min="0"
            id="src-price"
            placeholder="e.g 20PKR"
          />
        </div>
        <label>
          Service require data(information which required from the client for
          this service)
        </label>
        <label htmlFor="src-input1">required input-1</label>
        <input
          type="text"
          name=""
          defaultValue={InputValues[0].value}
          id="src-input1"
          placeholder="e.g Enter IMEI...."
        />
        <div className="flex-box">
          <label htmlFor="src-input2">required input-2</label>
          <label htmlFor="src-input3">required input-3</label>
        </div>
        <div className="flex-box">
          <input
            type="text"
            id="src-input2"
            defaultValue={InputValues[1].value}
            placeholder="e.g Enter card number..."
          />
          <input
            type="text"
            id="src-input3"
            defaultValue={InputValues[2].value}
            placeholder="e.g Enter wildcard number..."
          />
        </div>
        <div className="flex-box">
          <label htmlFor="src-input4">required input-4</label>
        </div>
        <div className="flex-box">
          <input
            type="text"
            id="src-input4"
            defaultValue={InputValues[3].value}
            placeholder="e.g Enter device ID number..."
          />
        </div>
        <br />
        {LoadingState === false ? (
          <button type="submit">
            <i className="fa fa-save"></i> Save
          </button>
        ) : (
          <div
            style={{
              width: 189,
              display: "block",
              marginTop: 9,
            }}
          >
            <Loading />
          </div>
        )}

        {message && (
          <InlineMessage type={message.type} message={message.message} />
        )}
      </form>
    </div>
  );
};
export default NewPost;
