import axios from "axios";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { ShowModalAction } from "../store/actions";
import Loading from "./loading";

function DefLabels() {
  const dispatch = useDispatch();
  const [LabelList, setLabelList] = useState([]);
  const [loading, setLoading] = useState(false);
  const getDefList = async () => {
    setLoading(true);
    try {
      await axios.get("/admin/api/getDefaults/").then((res) => {
        if (res.data.length > 0) {
          setLoading(false);
          setLabelList(res.data);
        }
      });
    } catch (err) {
      setLoading(false);
      alert(err.message);
    }
  };
  const CompRefresh = () => {
    getDefList();
  };
  useEffect(() => {
    getDefList();
  }, []);
  const DataTable = () => {
    return (
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>label</th>
            <th>value</th>
            <th>status</th>
          </tr>
        </thead>
        <tbody>
          {LabelList.map((label) => {
            return (
              <tr
                key={label.id}
                onClick={() => dispatch(ShowModalAction("def-edit", label.id))}
              >
                <td>{label.id}</td>
                <td>{label.label}</td>
                <td>{label.value}</td>
                <td
                  style={
                    label.active === 1
                      ? { background: "#afdbff", textAlign: "center" }
                      : { background: "#f3b49d", textAlign: "center" }
                  }
                ></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    );
  };
  return (
    <div className="layout">
      <div className="cat-list flex-box">
        <h3>Users</h3>
        <p className="refresh-btn" onClick={CompRefresh}>
          <i className="fa fa-refresh"></i>
        </p>
      </div>
      <div className="list-view">
        {loading && <Loading />}
        {!loading && <DataTable />}
      </div>
    </div>
  );
}
export default DefLabels;
